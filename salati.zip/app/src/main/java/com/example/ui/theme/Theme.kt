package com.example.ui.theme

import android.os.Build
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.dynamicDarkColorScheme
import androidx.compose.material3.dynamicLightColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext

private val SalatiDarkColorScheme = darkColorScheme(
    primary = GoldPrimary,
    onPrimary = Color(0xFF231800),
    primaryContainer = GoldContainer,
    onPrimaryContainer = GoldSecondary,
    secondary = EmeraldBorder,
    onSecondary = TextPrimary,
    secondaryContainer = EmeraldSurface,
    onSecondaryContainer = TextPrimary,
    tertiary = CrimsonLight,
    onTertiary = Color.White,
    tertiaryContainer = CrimsonContainer,
    onTertiaryContainer = Color(0xFFFFDAD8),
    background = DarkBackground,
    onBackground = TextPrimary,
    surface = DarkSurface,
    onSurface = TextPrimary,
    surfaceVariant = DarkSurfaceElevated,
    onSurfaceVariant = TextSecondary,
    outline = DarkCardBorder
)

private val SalatiLightColorScheme = lightColorScheme(
    primary = Color(0xFF785900),
    onPrimary = Color.White,
    primaryContainer = Color(0xFFFFDF9E),
    onPrimaryContainer = Color(0xFF261900),
    secondary = Color(0xFF144D40),
    onSecondary = Color.White,
    secondaryContainer = Color(0xFFA7F2DC),
    onSecondaryContainer = Color(0xFF002019),
    tertiary = CrimsonPrimary,
    onTertiary = Color.White,
    background = Color(0xFFF6FBF8),
    onBackground = Color(0xFF161D1A),
    surface = Color(0xFFFFFFFF),
    onSurface = Color(0xFF161D1A),
    surfaceVariant = Color(0xFFE0EAE5),
    onSurfaceVariant = Color(0xFF3F4945),
    outline = Color(0xFFB0BFBA)
)

@Composable
fun MyApplicationTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    dynamicColor: Boolean = false, // Keep intentional Islamic aesthetic
    content: @Composable () -> Unit,
) {
    val colorScheme = when {
        dynamicColor && Build.VERSION.SDK_INT >= Build.VERSION_CODES.S -> {
            val context = LocalContext.current
            if (darkTheme) dynamicDarkColorScheme(context) else dynamicLightColorScheme(context)
        }
        darkTheme -> SalatiDarkColorScheme
        else -> SalatiDarkColorScheme // Default to spiritual rich dark theme for exquisite contrast
    }

    MaterialTheme(
        colorScheme = colorScheme,
        typography = Typography,
        content = content
    )
}
