package com.example.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.model.*
import com.example.data.preferences.AppPreferences
import com.example.service.AthanAudioPlayer
import com.example.service.AthanNotificationManager
import com.example.util.WallpaperHelper
import com.example.util.WallpaperTarget
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import java.time.LocalDate
import java.time.LocalTime
import java.time.format.DateTimeFormatter
import java.util.Locale

enum class AppTab {
    PRAYER_TIMES,
    WALLPAPERS,
    TASBEEH,
    QIBLA
}

data class SalatiUiState(
    val selectedTab: AppTab = AppTab.PRAYER_TIMES,
    val selectedGovernorate: Governorate = IraqGovernorates.getById("karbala"),
    val dayPrayerTimes: DayPrayerTimes? = null,
    val currentDateGregorian: String = "",
    val currentDateHijri: String = "",
    val currentTimeString: String = "",
    val isGovernoratePickerOpen: Boolean = false,
    val governorateSearchQuery: String = "",
    val isAthanPlaying: Boolean = false,
    val wallpapers: List<HusainiWallpaper> = WallpaperRepository.wallpapers,
    val selectedWallpaperCategory: WallpaperCategory = WallpaperCategory.ALL,
    val activePreviewWallpaper: HusainiWallpaper? = null,
    val wallpaperActionMessage: String? = null,
    // Tasbeeh state: Fatima al-Zahra (AS)
    val tasbeehStep: Int = 0, // 0: Allahu Akbar (34), 1: Alhamdulillah (33), 2: SubhanAllah (33)
    val tasbeehCurrentCount: Int = 0,
    val tasbeehCompletedCycles: Int = 0,
    // Qibla
    val qiblaBearing: Double = 0.0,
    val distanceToKaabaKm: Int = 0
)

class PrayerTimesViewModel(application: Application) : AndroidViewModel(application) {

    private val preferences = AppPreferences(application)
    private val notificationManager = AthanNotificationManager(application)
    val athanAudioPlayer = AthanAudioPlayer()

    private val _uiState = MutableStateFlow(SalatiUiState())
    val uiState: StateFlow<SalatiUiState> = _uiState.asStateFlow()

    private var tickerJob: Job? = null

    init {
        val savedGovId = preferences.selectedGovernorateId
        val initialGov = IraqGovernorates.getById(savedGovId)

        athanAudioPlayer.setOnPlayingStateChanged { playing ->
            _uiState.update { it.copy(isAthanPlaying = playing) }
        }

        selectGovernorate(initialGov)
        startClockTicker()
    }

    private fun startClockTicker() {
        tickerJob?.cancel()
        tickerJob = viewModelScope.launch {
            while (isActive) {
                updateTimes()
                delay(1000)
            }
        }
    }

    fun selectTab(tab: AppTab) {
        _uiState.update { it.copy(selectedTab = tab) }
    }

    fun openGovernoratePicker() {
        _uiState.update { it.copy(isGovernoratePickerOpen = true, governorateSearchQuery = "") }
    }

    fun closeGovernoratePicker() {
        _uiState.update { it.copy(isGovernoratePickerOpen = false) }
    }

    fun updateGovernorateSearchQuery(query: String) {
        _uiState.update { it.copy(governorateSearchQuery = query) }
    }

    fun selectGovernorate(governorate: Governorate) {
        preferences.selectedGovernorateId = governorate.id
        val bearing = PrayerCalculator.getQiblaBearing(governorate)
        val distance = PrayerCalculator.getDistanceToKaabaKm(governorate)

        _uiState.update {
            it.copy(
                selectedGovernorate = governorate,
                isGovernoratePickerOpen = false,
                qiblaBearing = bearing,
                distanceToKaabaKm = distance
            )
        }
        updateTimes()
        scheduleAthanNotifications(governorate)
    }

    private fun updateTimes() {
        val gov = _uiState.value.selectedGovernorate
        val today = LocalDate.now()
        val now = LocalTime.now()

        val dayTimes = PrayerCalculator.calculate(today, gov, now)

        // Read preferences for enabled items
        val updatedItems = dayTimes.items.map { item ->
            item.copy(
                isNotificationEnabled = preferences.isNotificationEnabledForPrayer(item.type.id)
            )
        }

        val dateFormatter = DateTimeFormatter.ofPattern("EEEE، d MMMM yyyy", Locale("ar"))
        val timeFormatter = DateTimeFormatter.ofPattern("hh:mm:ss a", Locale("ar"))

        _uiState.update {
            it.copy(
                dayPrayerTimes = dayTimes.copy(items = updatedItems),
                currentDateGregorian = today.format(dateFormatter),
                currentDateHijri = PrayerCalculator.getHijriDate(today),
                currentTimeString = now.format(timeFormatter)
            )
        }
    }

    fun togglePrayerNotification(prayerType: PrayerType) {
        val currentEnabled = preferences.isNotificationEnabledForPrayer(prayerType.id)
        val newEnabled = !currentEnabled
        preferences.setNotificationEnabledForPrayer(prayerType.id, newEnabled)

        updateTimes()

        if (newEnabled) {
            val gov = _uiState.value.selectedGovernorate
            _uiState.value.dayPrayerTimes?.items?.firstOrNull { it.type == prayerType }?.let { item ->
                notificationManager.scheduleAthan(item, gov)
            }
        }
    }

    private fun scheduleAthanNotifications(governorate: Governorate) {
        val today = LocalDate.now()
        val dayTimes = PrayerCalculator.calculate(today, governorate)
        for (item in dayTimes.items) {
            if (item.type.isAthanPrayer && preferences.isNotificationEnabledForPrayer(item.type.id)) {
                notificationManager.scheduleAthan(item, governorate, today)
            }
        }
    }

    fun toggleAthanAudio() {
        if (athanAudioPlayer.isPlaying()) {
            athanAudioPlayer.stop()
        } else {
            athanAudioPlayer.playAthanTone()
        }
    }

    // Wallpaper Actions
    fun selectWallpaperCategory(category: WallpaperCategory) {
        _uiState.update { it.copy(selectedWallpaperCategory = category) }
    }

    fun openWallpaperPreview(wallpaper: HusainiWallpaper) {
        _uiState.update { it.copy(activePreviewWallpaper = wallpaper) }
    }

    fun closeWallpaperPreview() {
        _uiState.update { it.copy(activePreviewWallpaper = null) }
    }

    fun applyWallpaper(target: WallpaperTarget) {
        val wallpaper = _uiState.value.activePreviewWallpaper ?: return
        viewModelScope.launch {
            val result = WallpaperHelper.applyWallpaper(
                getApplication(),
                wallpaper.drawableRes,
                target
            )
            val message = if (result.isSuccess) {
                when (target) {
                    WallpaperTarget.HOME -> "تم تعيين خلفية \"${wallpaper.title}\" للشاشة الرئيسية مباركاً"
                    WallpaperTarget.LOCK -> "تم تعيين خلفية \"${wallpaper.title}\" لشاشة القفل مباركاً"
                    WallpaperTarget.BOTH -> "تم تعيين خلفية \"${wallpaper.title}\" لكلا الشاشتين مباركاً"
                }
            } else {
                "تعذر تعيين الخلفية، يرجى المحاولة لاحقاً"
            }
            _uiState.update { it.copy(wallpaperActionMessage = message) }
            delay(3000)
            _uiState.update { it.copy(wallpaperActionMessage = null) }
        }
    }

    // Tasbeeh Actions
    fun incrementTasbeeh() {
        val currentStep = _uiState.value.tasbeehStep
        val currentCount = _uiState.value.tasbeehCurrentCount
        val maxForStep = when (currentStep) {
            0 -> 34 // Allahu Akbar
            1 -> 33 // Alhamdulillah
            2 -> 33 // SubhanAllah
            else -> 33
        }

        if (currentCount + 1 >= maxForStep) {
            if (currentStep < 2) {
                _uiState.update {
                    it.copy(
                        tasbeehStep = currentStep + 1,
                        tasbeehCurrentCount = 0
                    )
                }
            } else {
                // Completed whole Tasbeeh of Fatima (AS)
                _uiState.update {
                    it.copy(
                        tasbeehStep = 0,
                        tasbeehCurrentCount = 0,
                        tasbeehCompletedCycles = it.tasbeehCompletedCycles + 1
                    )
                }
            }
        } else {
            _uiState.update { it.copy(tasbeehCurrentCount = currentCount + 1) }
        }
    }

    fun resetTasbeeh() {
        _uiState.update {
            it.copy(
                tasbeehStep = 0,
                tasbeehCurrentCount = 0
            )
        }
    }

    override fun onCleared() {
        super.onCleared()
        tickerJob?.cancel()
        athanAudioPlayer.stop()
    }
}
