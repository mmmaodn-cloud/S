package com.example.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.material3.Scaffold
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.unit.LayoutDirection
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.ui.components.GovernoratePickerSheet
import com.example.ui.components.SalatiBottomNav
import com.example.ui.screens.PrayerTimesScreen
import com.example.ui.screens.QiblaScreen
import com.example.ui.screens.TasbeehScreen
import com.example.ui.screens.WallpapersScreen
import com.example.ui.theme.DarkBackground

@Composable
fun SalatiApp(
    viewModel: PrayerTimesViewModel = viewModel()
) {
    val uiState by viewModel.uiState.collectAsStateWithLifecycle()

    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
        Scaffold(
            modifier = Modifier.fillMaxSize(),
            bottomBar = {
                SalatiBottomNav(
                    selectedTab = uiState.selectedTab,
                    onTabSelected = { viewModel.selectTab(it) }
                )
            },
            containerColor = DarkBackground
        ) { innerPadding ->
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(innerPadding)
                    .background(DarkBackground)
            ) {
                when (uiState.selectedTab) {
                    AppTab.PRAYER_TIMES -> {
                        PrayerTimesScreen(
                            viewModel = viewModel,
                            uiState = uiState
                        )
                    }
                    AppTab.WALLPAPERS -> {
                        WallpapersScreen(
                            viewModel = viewModel,
                            uiState = uiState
                        )
                    }
                    AppTab.TASBEEH -> {
                        TasbeehScreen(
                            viewModel = viewModel,
                            uiState = uiState
                        )
                    }
                    AppTab.QIBLA -> {
                        QiblaScreen(
                            viewModel = viewModel,
                            uiState = uiState
                        )
                    }
                }

                // Governorate Picker Bottom Sheet
                if (uiState.isGovernoratePickerOpen) {
                    GovernoratePickerSheet(
                        selectedGovernorate = uiState.selectedGovernorate,
                        searchQuery = uiState.governorateSearchQuery,
                        onSearchQueryChange = { viewModel.updateGovernorateSearchQuery(it) },
                        onSelectGovernorate = { viewModel.selectGovernorate(it) },
                        onDismiss = { viewModel.closeGovernoratePicker() }
                    )
                }
            }
        }
    }
}
