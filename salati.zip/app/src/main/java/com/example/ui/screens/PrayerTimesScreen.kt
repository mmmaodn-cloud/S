package com.example.ui.screens

import android.Manifest
import android.content.pm.PackageManager
import android.os.Build
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.*
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import com.example.data.model.PrayerTimeItem
import com.example.data.model.PrayerType
import com.example.ui.PrayerTimesViewModel
import com.example.ui.SalatiUiState
import com.example.ui.theme.*

@Composable
fun PrayerTimesScreen(
    viewModel: PrayerTimesViewModel,
    uiState: SalatiUiState,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    var hasNotificationPermission by remember {
        mutableStateOf(
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                ContextCompat.checkSelfPermission(
                    context,
                    Manifest.permission.POST_NOTIFICATIONS
                ) == PackageManager.PERMISSION_GRANTED
            } else {
                true
            }
        )
    }

    val permissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { granted ->
        hasNotificationPermission = granted
    }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp),
        contentPadding = PaddingValues(top = 12.dp, bottom = 24.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        // 1. Top Bar / Governorate Header
        item {
            GovernorateHeaderCard(
                governorateTitle = uiState.selectedGovernorate.titleWithSanctity,
                hijriDate = uiState.currentDateHijri,
                gregorianDate = uiState.currentDateGregorian,
                onOpenGovernoratePicker = { viewModel.openGovernoratePicker() }
            )
        }

        // 2. Notification Permission Warning (if needed)
        if (!hasNotificationPermission && Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            item {
                NotificationPermissionBanner(
                    onRequestPermission = {
                        permissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
                    }
                )
            }
        }

        // 3. Next Prayer Countdown Hero Card
        item {
            uiState.dayPrayerTimes?.let { dayTimes ->
                NextPrayerHeroCard(
                    nextPrayer = dayTimes.nextPrayer,
                    remainingSeconds = dayTimes.remainingSecondsToNext,
                    currentTime = uiState.currentTimeString
                )
            }
        }

        // 4. Athan Audio Test Bar
        item {
            AthanAudioPreviewCard(
                isPlaying = uiState.isAthanPlaying,
                onToggleAthan = { viewModel.toggleAthanAudio() }
            )
        }

        // 5. Section Header for Prayer Schedule
        item {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 4.dp, vertical = 2.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "أوقات الصلوات اليومية",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    color = GoldSecondary
                )
                Text(
                    text = "حسب توقيت العراق (GMT+3)",
                    style = MaterialTheme.typography.bodySmall,
                    color = TextTertiary
                )
            }
        }

        // 6. Prayer Times List Items
        uiState.dayPrayerTimes?.items?.let { prayerItems ->
            items(prayerItems) { item ->
                PrayerTimeRowCard(
                    item = item,
                    onToggleNotification = {
                        viewModel.togglePrayerNotification(item.type)
                    }
                )
            }
        }
    }
}

@Composable
private fun GovernorateHeaderCard(
    governorateTitle: String,
    hijriDate: String,
    gregorianDate: String,
    onOpenGovernoratePicker: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(20.dp))
            .clickable(onClick = onOpenGovernoratePicker)
            .border(1.dp, EmeraldBorder, RoundedCornerShape(20.dp))
            .testTag("governorate_header_card"),
        colors = CardDefaults.cardColors(containerColor = DarkSurfaceElevated)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.weight(1f)
                ) {
                    Box(
                        modifier = Modifier
                            .size(40.dp)
                            .background(EmeraldSurface, CircleShape),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.LocationOn,
                            contentDescription = "المحافظة",
                            tint = GoldPrimary,
                            modifier = Modifier.size(22.dp)
                        )
                    }
                    Spacer(modifier = Modifier.width(12.dp))
                    Column {
                        Text(
                            text = governorateTitle,
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            color = TextPrimary
                        )
                        Text(
                            text = "اضغط لتغيير المحافظة العراقية",
                            style = MaterialTheme.typography.bodySmall,
                            color = GoldMuted,
                            fontSize = 12.sp
                        )
                    }
                }

                FilledTonalButton(
                    onClick = onOpenGovernoratePicker,
                    colors = ButtonDefaults.filledTonalButtonColors(
                        containerColor = GoldContainer,
                        contentColor = GoldSecondary
                    ),
                    shape = RoundedCornerShape(12.dp),
                    contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp),
                    modifier = Modifier.testTag("change_city_button")
                ) {
                    Text(text = "تغيير", fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                }
            }

            HorizontalDivider(
                modifier = Modifier.padding(vertical = 12.dp),
                color = EmeraldBorder.copy(alpha = 0.5f)
            )

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.CalendarToday,
                        contentDescription = null,
                        tint = GoldPrimary,
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = hijriDate,
                        style = MaterialTheme.typography.bodyMedium,
                        fontWeight = FontWeight.SemiBold,
                        color = GoldSecondary
                    )
                }
                Text(
                    text = gregorianDate,
                    style = MaterialTheme.typography.bodySmall,
                    color = TextSecondary
                )
            }
        }
    }
}

@Composable
private fun NextPrayerHeroCard(
    nextPrayer: PrayerTimeItem?,
    remainingSeconds: Long,
    currentTime: String
) {
    val hours = (remainingSeconds / 3600).coerceAtLeast(0)
    val minutes = ((remainingSeconds % 3600) / 60).coerceAtLeast(0)
    val seconds = (remainingSeconds % 60).coerceAtLeast(0)

    val timeString = "%02d:%02d:%02d".format(hours, minutes, seconds)

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(24.dp))
            .border(
                width = 1.5.dp,
                brush = Brush.horizontalGradient(
                    listOf(GoldPrimary, GoldMuted, GoldPrimary)
                ),
                shape = RoundedCornerShape(24.dp)
            )
            .testTag("next_prayer_hero_card"),
        colors = CardDefaults.cardColors(
            containerColor = Color.Transparent
        )
    ) {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .background(
                    Brush.verticalGradient(
                        colors = listOf(EmeraldSurface, DarkSurfaceElevated)
                    )
                )
                .padding(20.dp)
        ) {
            Column(
                modifier = Modifier.fillMaxWidth(),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.AccessTime,
                        contentDescription = null,
                        tint = GoldSecondary,
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "الصلاة القادمة: ${nextPrayer?.type?.arabicName ?: "الفجر"}",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = GoldSecondary
                    )
                    if (nextPrayer != null) {
                        Text(
                            text = " (${nextPrayer.formattedTime12h})",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Normal,
                            color = TextPrimary
                        )
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))

                // Large Countdown display
                Text(
                    text = timeString,
                    style = MaterialTheme.typography.displaySmall,
                    fontWeight = FontWeight.ExtraBold,
                    color = TextPrimary,
                    letterSpacing = 2.sp,
                    modifier = Modifier.testTag("countdown_timer_text")
                )

                Spacer(modifier = Modifier.height(4.dp))

                Text(
                    text = "متبقي على رفع الأذان",
                    style = MaterialTheme.typography.bodySmall,
                    color = TextSecondary
                )

                Spacer(modifier = Modifier.height(8.dp))

                Surface(
                    color = DarkBackground.copy(alpha = 0.6f),
                    shape = RoundedCornerShape(12.dp),
                    border = borderOrNull(1.dp, EmeraldBorder)
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "الوقت الحالي: ",
                            style = MaterialTheme.typography.bodySmall,
                            color = TextTertiary
                        )
                        Text(
                            text = currentTime,
                            style = MaterialTheme.typography.bodySmall,
                            color = GoldSecondary,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun AthanAudioPreviewCard(
    isPlaying: Boolean,
    onToggleAthan: () -> Unit
) {
    val infiniteTransition = rememberInfiniteTransition(label = "athan_pulse")
    val pulseAlpha by infiniteTransition.animateFloat(
        initialValue = 0.4f,
        targetValue = 1.0f,
        animationSpec = infiniteRepeatable(
            animation = tween(800, easing = LinearEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "pulse"
    )

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(18.dp))
            .border(
                1.dp,
                if (isPlaying) GoldPrimary else EmeraldBorder,
                RoundedCornerShape(18.dp)
            )
            .testTag("athan_preview_card"),
        colors = CardDefaults.cardColors(
            containerColor = if (isPlaying) GoldContainer.copy(alpha = 0.5f) else DarkSurfaceElevated
        )
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 12.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.weight(1f)
            ) {
                Box(
                    modifier = Modifier
                        .size(38.dp)
                        .background(
                            if (isPlaying) GoldPrimary else EmeraldSurface,
                            CircleShape
                        ),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = if (isPlaying) Icons.Default.VolumeUp else Icons.Default.VolumeDown,
                        contentDescription = null,
                        tint = if (isPlaying) Color(0xFF1E1400) else GoldPrimary,
                        modifier = Modifier.size(20.dp)
                    )
                }
                Spacer(modifier = Modifier.width(12.dp))
                Column {
                    Text(
                        text = if (isPlaying) "جاري تشغيل نداء الأذان..." else "تجربة صوت الأذان",
                        style = MaterialTheme.typography.bodyMedium,
                        fontWeight = FontWeight.Bold,
                        color = if (isPlaying) GoldSecondary else TextPrimary
                    )
                    Text(
                        text = if (isPlaying) "اضغط للإيقاف" else "استمع إلى نداء الأذان بالصوت المبارك",
                        style = MaterialTheme.typography.bodySmall,
                        color = TextSecondary,
                        fontSize = 12.sp
                    )
                }
            }

            Button(
                onClick = onToggleAthan,
                colors = ButtonDefaults.buttonColors(
                    containerColor = if (isPlaying) CrimsonPrimary else GoldPrimary,
                    contentColor = if (isPlaying) Color.White else Color(0xFF1E1400)
                ),
                shape = RoundedCornerShape(12.dp),
                contentPadding = PaddingValues(horizontal = 14.dp, vertical = 8.dp),
                modifier = Modifier.testTag("toggle_athan_audio_button")
            ) {
                Icon(
                    imageVector = if (isPlaying) Icons.Default.Stop else Icons.Default.PlayArrow,
                    contentDescription = null,
                    modifier = Modifier.size(18.dp)
                )
                Spacer(modifier = Modifier.width(4.dp))
                Text(
                    text = if (isPlaying) "إيقاف" else "تشغيل",
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Bold
                )
            }
        }
    }
}

@Composable
private fun PrayerTimeRowCard(
    item: PrayerTimeItem,
    onToggleNotification: () -> Unit
) {
    val prayerIcon = getPrayerIcon(item.type)
    val isNext = item.isNext

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(16.dp))
            .border(
                width = if (isNext) 1.5.dp else 1.dp,
                color = if (isNext) GoldPrimary else EmeraldBorder.copy(alpha = 0.5f),
                shape = RoundedCornerShape(16.dp)
            )
            .testTag("prayer_row_${item.type.id}"),
        colors = CardDefaults.cardColors(
            containerColor = when {
                isNext -> EmeraldSurface
                item.isPassed -> DarkSurface.copy(alpha = 0.6f)
                else -> DarkSurfaceElevated
            }
        )
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 12.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            // Icon & Name
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    modifier = Modifier
                        .size(38.dp)
                        .background(
                            if (isNext) GoldContainer else DarkSurfaceElevated,
                            CircleShape
                        ),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = prayerIcon,
                        contentDescription = item.type.arabicName,
                        tint = if (isNext) GoldPrimary else if (item.isPassed) TextTertiary else TextSecondary,
                        modifier = Modifier.size(20.dp)
                    )
                }
                Spacer(modifier = Modifier.width(12.dp))
                Column {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(
                            text = item.type.arabicName,
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = if (isNext) FontWeight.Bold else FontWeight.SemiBold,
                            color = if (isNext) GoldSecondary else if (item.isPassed) TextSecondary else TextPrimary
                        )
                        if (isNext) {
                            Spacer(modifier = Modifier.width(8.dp))
                            Surface(
                                color = GoldPrimary,
                                shape = RoundedCornerShape(6.dp)
                            ) {
                                Text(
                                    text = "الحالية",
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = Color(0xFF221600),
                                    modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                )
                            }
                        }
                    }
                    Text(
                        text = item.type.englishName,
                        style = MaterialTheme.typography.bodySmall,
                        color = TextTertiary,
                        fontSize = 11.sp
                    )
                }
            }

            // Time and Notification Bell
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                    text = item.formattedTime12h,
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    color = if (isNext) GoldPrimary else if (item.isPassed) TextTertiary else TextPrimary,
                    modifier = Modifier.testTag("prayer_time_${item.type.id}")
                )

                if (item.type.isAthanPrayer) {
                    Spacer(modifier = Modifier.width(10.dp))
                    IconButton(
                        onClick = onToggleNotification,
                        modifier = Modifier
                            .size(36.dp)
                            .testTag("notify_btn_${item.type.id}")
                    ) {
                        Icon(
                            imageVector = if (item.isNotificationEnabled) Icons.Filled.NotificationsActive else Icons.Outlined.NotificationsOff,
                            contentDescription = "تنبيه الأذان",
                            tint = if (item.isNotificationEnabled) GoldPrimary else TextTertiary,
                            modifier = Modifier.size(20.dp)
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun NotificationPermissionBanner(
    onRequestPermission: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(16.dp))
            .border(1.dp, CrimsonPrimary, RoundedCornerShape(16.dp))
            .testTag("notification_permission_banner"),
        colors = CardDefaults.cardColors(containerColor = CrimsonContainer.copy(alpha = 0.5f))
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.weight(1f)
            ) {
                Icon(
                    imageVector = Icons.Default.Notifications,
                    contentDescription = null,
                    tint = CrimsonLight,
                    modifier = Modifier.size(24.dp)
                )
                Spacer(modifier = Modifier.width(10.dp))
                Column {
                    Text(
                        text = "تفعيل إشعارات الأذان",
                        style = MaterialTheme.typography.bodyMedium,
                        fontWeight = FontWeight.Bold,
                        color = TextPrimary
                    )
                    Text(
                        text = "لتصلك تنبيهات وقت الصلاة في موعدها الدقيق",
                        style = MaterialTheme.typography.bodySmall,
                        color = TextSecondary,
                        fontSize = 11.sp
                    )
                }
            }

            Button(
                onClick = onRequestPermission,
                colors = ButtonDefaults.buttonColors(
                    containerColor = CrimsonLight,
                    contentColor = Color.White
                ),
                shape = RoundedCornerShape(10.dp),
                contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp)
            ) {
                Text("تفعيل", fontSize = 12.sp, fontWeight = FontWeight.Bold)
            }
        }
    }
}

private fun getPrayerIcon(type: PrayerType): ImageVector {
    return when (type) {
        PrayerType.IMSAK -> Icons.Default.NightsStay
        PrayerType.FAJR -> Icons.Default.Brightness3
        PrayerType.SUNRISE -> Icons.Default.WbSunny
        PrayerType.DHUHR -> Icons.Default.WbSunny
        PrayerType.ASR -> Icons.Default.WbTwilight
        PrayerType.MAGHRIB -> Icons.Default.Brightness4
        PrayerType.ISHA -> Icons.Default.Nightlight
        PrayerType.MIDNIGHT -> Icons.Default.Bedtime
    }
}

@Composable
private fun borderOrNull(width: androidx.compose.ui.unit.Dp, color: Color) =
    androidx.compose.foundation.BorderStroke(width, color)
