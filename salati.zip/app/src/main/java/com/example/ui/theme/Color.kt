package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Spiritual Islamic & Husaini Palette
val EmeraldDark = Color(0xFF081814)
val EmeraldMedium = Color(0xFF0F2B24)
val EmeraldSurface = Color(0xFF14382F)
val EmeraldBorder = Color(0xFF1D4D40)

// Sacred Gold Accents (Golden Dome of Karbala)
val GoldPrimary = Color(0xFFE5B94D)
val GoldSecondary = Color(0xFFFFD76F)
val GoldMuted = Color(0xFFB89339)
val GoldContainer = Color(0xFF2C2513)

// Husaini Crimson
val CrimsonPrimary = Color(0xFF9E1F29)
val CrimsonLight = Color(0xFFCC333F)
val CrimsonContainer = Color(0xFF2A0C10)

// Text and neutral tones
val PureWhite = Color(0xFFFFFFFF)
val TextPrimary = Color(0xFFF2F5F3)
val TextSecondary = Color(0xFFADC0BA)
val TextTertiary = Color(0xFF708680)

val DarkBackground = Color(0xFF070F0D)
val DarkSurface = Color(0xFF0E1A17)
val DarkSurfaceElevated = Color(0xFF162521)
val DarkCardBorder = Color(0x33E5B94D)
