package com.example.ui.components

import androidx.compose.foundation.border
import androidx.compose.foundation.layout.size
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AccessTime
import androidx.compose.material.icons.filled.Explore
import androidx.compose.material.icons.filled.VolunteerActivism
import androidx.compose.material.icons.filled.Wallpaper
import androidx.compose.material.icons.outlined.AccessTime
import androidx.compose.material.icons.outlined.Explore
import androidx.compose.material.icons.outlined.VolunteerActivism
import androidx.compose.material.icons.outlined.Wallpaper
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.AppTab
import com.example.ui.theme.*

data class NavItem(
    val tab: AppTab,
    val title: String,
    val selectedIcon: ImageVector,
    val unselectedIcon: ImageVector,
    val tag: String
)

@Composable
fun SalatiBottomNav(
    selectedTab: AppTab,
    onTabSelected: (AppTab) -> Unit,
    modifier: Modifier = Modifier
) {
    val items = listOf(
        NavItem(
            tab = AppTab.PRAYER_TIMES,
            title = "مواقيت الصلاة",
            selectedIcon = Icons.Filled.AccessTime,
            unselectedIcon = Icons.Outlined.AccessTime,
            tag = "tab_prayer_times"
        ),
        NavItem(
            tab = AppTab.WALLPAPERS,
            title = "خلفيات حسينية",
            selectedIcon = Icons.Filled.Wallpaper,
            unselectedIcon = Icons.Outlined.Wallpaper,
            tag = "tab_wallpapers"
        ),
        NavItem(
            tab = AppTab.TASBEEH,
            title = "تسبيح وأدعية",
            selectedIcon = Icons.Filled.VolunteerActivism,
            unselectedIcon = Icons.Outlined.VolunteerActivism,
            tag = "tab_tasbeeh"
        ),
        NavItem(
            tab = AppTab.QIBLA,
            title = "القبلة",
            selectedIcon = Icons.Filled.Explore,
            unselectedIcon = Icons.Outlined.Explore,
            tag = "tab_qibla"
        )
    )

    NavigationBar(
        modifier = modifier.border(
            width = 1.dp,
            color = EmeraldBorder.copy(alpha = 0.5f)
        ),
        containerColor = DarkSurfaceElevated,
        contentColor = TextPrimary
    ) {
        items.forEach { item ->
            val isSelected = (selectedTab == item.tab)
            NavigationBarItem(
                selected = isSelected,
                onClick = { onTabSelected(item.tab) },
                icon = {
                    Icon(
                        imageVector = if (isSelected) item.selectedIcon else item.unselectedIcon,
                        contentDescription = item.title,
                        modifier = Modifier.size(22.dp)
                    )
                },
                label = {
                    Text(
                        text = item.title,
                        fontSize = 11.sp,
                        color = if (isSelected) GoldSecondary else TextSecondary
                    )
                },
                colors = NavigationBarItemDefaults.colors(
                    selectedIconColor = GoldPrimary,
                    selectedTextColor = GoldSecondary,
                    indicatorColor = GoldContainer,
                    unselectedIconColor = TextTertiary,
                    unselectedTextColor = TextTertiary
                ),
                modifier = Modifier.testTag(item.tag)
            )
        }
    }
}
