package com.example.ui.screens

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.example.data.model.HusainiWallpaper
import com.example.data.model.WallpaperCategory
import com.example.ui.PrayerTimesViewModel
import com.example.ui.SalatiUiState
import com.example.ui.theme.*
import com.example.util.WallpaperTarget

@Composable
fun WallpapersScreen(
    viewModel: PrayerTimesViewModel,
    uiState: SalatiUiState,
    modifier: Modifier = Modifier
) {
    val filteredWallpapers = remember(uiState.selectedWallpaperCategory, uiState.wallpapers) {
        if (uiState.selectedWallpaperCategory == WallpaperCategory.ALL) {
            uiState.wallpapers
        } else {
            uiState.wallpapers.filter { it.category == uiState.selectedWallpaperCategory }
        }
    }

    Box(modifier = modifier.fillMaxSize()) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 16.dp)
        ) {
            // Header
            Spacer(modifier = Modifier.height(12.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = "خلفيات حسينية وعاشورائية",
                        style = MaterialTheme.typography.titleLarge,
                        fontWeight = FontWeight.Bold,
                        color = GoldSecondary
                    )
                    Text(
                        text = "صور فائقة الدقة لمرقد سيد الشهداء وأبي الفضل العباس (ع)",
                        style = MaterialTheme.typography.bodySmall,
                        color = TextSecondary
                    )
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            // Category Filter Chips
            LazyRow(
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                items(WallpaperCategory.values()) { category ->
                    val isSelected = (uiState.selectedWallpaperCategory == category)
                    FilterChip(
                        selected = isSelected,
                        onClick = { viewModel.selectWallpaperCategory(category) },
                        label = {
                            Text(
                                text = category.arabicTitle,
                                fontSize = 13.sp,
                                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal
                            )
                        },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = GoldPrimary,
                            selectedLabelColor = Color(0xFF1E1400),
                            containerColor = DarkSurfaceElevated,
                            labelColor = TextPrimary
                        ),
                        border = FilterChipDefaults.filterChipBorder(
                            enabled = true,
                            selected = isSelected,
                            borderColor = EmeraldBorder,
                            selectedBorderColor = GoldPrimary
                        )
                    )
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            // Wallpapers Grid
            LazyVerticalGrid(
                columns = GridCells.Fixed(2),
                horizontalArrangement = Arrangement.spacedBy(12.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp),
                contentPadding = PaddingValues(bottom = 24.dp),
                modifier = Modifier.fillMaxSize()
            ) {
                items(filteredWallpapers) { wallpaper ->
                    WallpaperCard(
                        wallpaper = wallpaper,
                        onClick = { viewModel.openWallpaperPreview(wallpaper) }
                    )
                }
            }
        }

        // Action Toast Message
        uiState.wallpaperActionMessage?.let { msg ->
            Surface(
                modifier = Modifier
                    .align(Alignment.BottomCenter)
                    .padding(bottom = 80.dp, start = 20.dp, end = 20.dp),
                shape = RoundedCornerShape(16.dp),
                color = EmeraldSurface,
                border = androidx.compose.foundation.BorderStroke(1.dp, GoldPrimary),
                shadowElevation = 8.dp
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 16.dp, vertical = 12.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        imageVector = Icons.Default.CheckCircle,
                        contentDescription = null,
                        tint = GoldPrimary,
                        modifier = Modifier.size(20.dp)
                    )
                    Spacer(modifier = Modifier.width(10.dp))
                    Text(
                        text = msg,
                        style = MaterialTheme.typography.bodyMedium,
                        color = TextPrimary,
                        fontWeight = FontWeight.SemiBold
                    )
                }
            }
        }

        // Fullscreen Preview Dialog
        uiState.activePreviewWallpaper?.let { previewWallpaper ->
            WallpaperPreviewDialog(
                wallpaper = previewWallpaper,
                onDismiss = { viewModel.closeWallpaperPreview() },
                onApply = { target -> viewModel.applyWallpaper(target) }
            )
        }
    }
}

@Composable
private fun WallpaperCard(
    wallpaper: HusainiWallpaper,
    onClick: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .height(260.dp)
            .clip(RoundedCornerShape(18.dp))
            .clickable(onClick = onClick)
            .border(1.dp, EmeraldBorder, RoundedCornerShape(18.dp))
            .testTag("wallpaper_item_${wallpaper.id}"),
        colors = CardDefaults.cardColors(containerColor = DarkSurfaceElevated)
    ) {
        Box(modifier = Modifier.fillMaxSize()) {
            Image(
                painter = painterResource(id = wallpaper.drawableRes),
                contentDescription = wallpaper.title,
                contentScale = ContentScale.Crop,
                modifier = Modifier.fillMaxSize()
            )

            // Gradient scrim for text readability
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(
                        Brush.verticalGradient(
                            colors = listOf(
                                Color.Transparent,
                                Color.Black.copy(alpha = 0.85f)
                            ),
                            startY = 200f
                        )
                    )
            )

            // Bottom Info
            Column(
                modifier = Modifier
                    .align(Alignment.BottomStart)
                    .padding(12.dp)
            ) {
                Text(
                    text = wallpaper.title,
                    style = MaterialTheme.typography.titleSmall,
                    fontWeight = FontWeight.Bold,
                    color = Color.White
                )
                Text(
                    text = wallpaper.subtitle,
                    style = MaterialTheme.typography.bodySmall,
                    color = GoldSecondary,
                    fontSize = 11.sp,
                    maxLines = 1
                )
            }

            // Quick Preview Icon Badge
            Box(
                modifier = Modifier
                    .align(Alignment.TopEnd)
                    .padding(8.dp)
                    .size(32.dp)
                    .background(Color.Black.copy(alpha = 0.5f), CircleShape),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = Icons.Default.Visibility,
                    contentDescription = "معاينة",
                    tint = GoldSecondary,
                    modifier = Modifier.size(16.dp)
                )
            }
        }
    }
}

@Composable
private fun WallpaperPreviewDialog(
    wallpaper: HusainiWallpaper,
    onDismiss: () -> Unit,
    onApply: (WallpaperTarget) -> Unit
) {
    var selectedTarget by remember { mutableStateOf<WallpaperTarget?>(null) }
    var showTargetOptions by remember { mutableStateOf(false) }

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(Color.Black)
        ) {
            // Full screen Image
            Image(
                painter = painterResource(id = wallpaper.drawableRes),
                contentDescription = wallpaper.title,
                contentScale = ContentScale.Crop,
                modifier = Modifier.fillMaxSize()
            )

            // Top Bar with Close button
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .statusBarsPadding()
                    .padding(horizontal = 16.dp, vertical = 8.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(
                    onClick = onDismiss,
                    modifier = Modifier
                        .background(Color.Black.copy(alpha = 0.5f), CircleShape)
                        .testTag("close_preview_button")
                ) {
                    Icon(
                        imageVector = Icons.Default.Close,
                        contentDescription = "إغلاق",
                        tint = Color.White
                    )
                }

                Surface(
                    color = Color.Black.copy(alpha = 0.5f),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Text(
                        text = wallpaper.title,
                        color = GoldSecondary,
                        fontWeight = FontWeight.Bold,
                        fontSize = 14.sp,
                        modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp)
                    )
                }
            }

            // Simulated Lock Screen Clock Preview
            Column(
                modifier = Modifier
                    .align(Alignment.TopCenter)
                    .padding(top = 110.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text(
                    text = "12:00",
                    fontSize = 58.sp,
                    fontWeight = FontWeight.Thin,
                    color = Color.White.copy(alpha = 0.9f)
                )
                Text(
                    text = "الخميس، 10 سبتمبر",
                    fontSize = 16.sp,
                    color = Color.White.copy(alpha = 0.75f)
                )
            }

            // Bottom Controls
            Column(
                modifier = Modifier
                    .align(Alignment.BottomCenter)
                    .fillMaxWidth()
                    .background(
                        Brush.verticalGradient(
                            colors = listOf(Color.Transparent, Color.Black.copy(alpha = 0.9f))
                        )
                    )
                    .navigationBarsPadding()
                    .padding(20.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                if (!showTargetOptions) {
                    Button(
                        onClick = { showTargetOptions = true },
                        colors = ButtonDefaults.buttonColors(
                            containerColor = GoldPrimary,
                            contentColor = Color(0xFF1E1400)
                        ),
                        shape = RoundedCornerShape(16.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(52.dp)
                            .testTag("apply_wallpaper_button")
                    ) {
                        Icon(
                            imageVector = Icons.Default.Wallpaper,
                            contentDescription = null,
                            modifier = Modifier.size(20.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "تعيين كخلفية للجهاز",
                            fontSize = 16.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                } else {
                    // Show options: Home screen, Lock screen, Both
                    Column(
                        modifier = Modifier.fillMaxWidth(),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Text(
                            text = "اختر وجهة الخلفية:",
                            color = GoldSecondary,
                            fontWeight = FontWeight.Bold,
                            fontSize = 14.sp,
                            modifier = Modifier.align(Alignment.CenterHorizontally)
                        )

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Button(
                                onClick = {
                                    onApply(WallpaperTarget.HOME)
                                    onDismiss()
                                },
                                colors = ButtonDefaults.buttonColors(containerColor = EmeraldSurface),
                                shape = RoundedCornerShape(12.dp),
                                modifier = Modifier.weight(1f).testTag("set_home_btn")
                            ) {
                                Text("الرئيسية", fontSize = 13.sp)
                            }

                            Button(
                                onClick = {
                                    onApply(WallpaperTarget.LOCK)
                                    onDismiss()
                                },
                                colors = ButtonDefaults.buttonColors(containerColor = EmeraldSurface),
                                shape = RoundedCornerShape(12.dp),
                                modifier = Modifier.weight(1f).testTag("set_lock_btn")
                            ) {
                                Text("شاشة القفل", fontSize = 13.sp)
                            }

                            Button(
                                onClick = {
                                    onApply(WallpaperTarget.BOTH)
                                    onDismiss()
                                },
                                colors = ButtonDefaults.buttonColors(containerColor = GoldPrimary),
                                shape = RoundedCornerShape(12.dp),
                                modifier = Modifier.weight(1f).testTag("set_both_btn")
                            ) {
                                Text("كلاهما", fontSize = 13.sp, color = Color(0xFF1E1400), fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                }
            }
        }
    }
}
