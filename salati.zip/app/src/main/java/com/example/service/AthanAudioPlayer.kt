package com.example.service

import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioTrack
import kotlinx.coroutines.*
import kotlin.math.sin

class AthanAudioPlayer {
    private var audioTrack: AudioTrack? = null
    private var playJob: Job? = null
    private var isPlayingListener: ((Boolean) -> Unit)? = null

    fun setOnPlayingStateChanged(listener: (Boolean) -> Unit) {
        this.isPlayingListener = listener
    }

    fun isPlaying(): Boolean = playJob?.isActive == true

    fun playAthanTone() {
        stop()

        playJob = CoroutineScope(Dispatchers.Default).launch {
            try {
                withContext(Dispatchers.Main) {
                    isPlayingListener?.invoke(true)
                }

                val sampleRate = 44100
                val minBufferSize = AudioTrack.getMinBufferSize(
                    sampleRate,
                    AudioFormat.CHANNEL_OUT_MONO,
                    AudioFormat.ENCODING_PCM_16BIT
                )

                val track = AudioTrack.Builder()
                    .setAudioAttributes(
                        AudioAttributes.Builder()
                            .setUsage(AudioAttributes.USAGE_MEDIA)
                            .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
                            .build()
                    )
                    .setAudioFormat(
                        AudioFormat.Builder()
                            .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                            .setSampleRate(sampleRate)
                            .setChannelMask(AudioFormat.CHANNEL_OUT_MONO)
                            .build()
                    )
                    .setBufferSizeInBytes(minBufferSize * 2)
                    .setTransferMode(AudioTrack.MODE_STREAM)
                    .build()

                audioTrack = track
                track.play()

                // Spiritual Maqam Bayati melody notes (Allahu Akbar, Hayya alas-Salah)
                // Frequencies in Hz: F4 (349), G4 (392), Ab4 (415), Bb4 (466), C5 (523), D5 (587)
                val sequence = listOf(
                    Pair(349.23, 0.7), // Allahu
                    Pair(415.30, 0.8), // Akbar
                    Pair(392.00, 1.2), // Allahu
                    Pair(349.23, 1.5), // Akbar
                    Pair(0.0, 0.3),    // Pause
                    Pair(349.23, 0.7), // Ash-hadu
                    Pair(392.00, 0.6), // an la
                    Pair(466.16, 0.9), // ilaha
                    Pair(415.30, 0.8), // illa
                    Pair(349.23, 1.5), // Allah
                    Pair(0.0, 0.3),
                    Pair(415.30, 0.7), // Hayya 'ala
                    Pair(466.16, 0.8), // as-Salah
                    Pair(523.25, 1.3), // Hayya 'ala
                    Pair(466.16, 0.9), // al-Falah
                    Pair(415.30, 1.0),
                    Pair(349.23, 1.8)  // Allahu Akbar
                )

                for (note in sequence) {
                    if (!isActive) break
                    val freq = note.first
                    val durationSec = note.second
                    val totalSamples = (sampleRate * durationSec).toInt()
                    val buffer = ShortArray(totalSamples)

                    if (freq > 0) {
                        for (i in 0 until totalSamples) {
                            val time = i.toDouble() / sampleRate
                            // Soft attack & exponential decay envelope
                            val progress = i.toDouble() / totalSamples
                            val envelope = when {
                                progress < 0.08 -> progress / 0.08
                                else -> kotlin.math.exp(-3.0 * (progress - 0.08))
                            }
                            // Harmonic rich organ/bell timbre (fundamental + 2nd & 3rd harmonics)
                            val wave1 = sin(2.0 * Math.PI * freq * time)
                            val wave2 = 0.4 * sin(2.0 * Math.PI * (freq * 2) * time)
                            val wave3 = 0.2 * sin(2.0 * Math.PI * (freq * 3) * time)
                            val combined = (wave1 + wave2 + wave3) * envelope * 0.45
                            buffer[i] = (combined * Short.MAX_VALUE).toInt().toShort()
                        }
                    }

                    track.write(buffer, 0, buffer.size)
                }

            } catch (e: Exception) {
                // Ignore cancellations
            } finally {
                withContext(Dispatchers.Main) {
                    isPlayingListener?.invoke(false)
                }
                audioTrack?.stop()
                audioTrack?.release()
                audioTrack = null
            }
        }
    }

    fun stop() {
        playJob?.cancel()
        playJob = null
        try {
            audioTrack?.stop()
            audioTrack?.release()
        } catch (e: Exception) {
            // Ignore
        }
        audioTrack = null
        isPlayingListener?.invoke(false)
    }
}
