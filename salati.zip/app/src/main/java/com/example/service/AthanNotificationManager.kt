package com.example.service

import android.app.AlarmManager
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.media.AudioAttributes
import android.media.RingtoneManager
import android.os.Build
import androidx.core.app.NotificationCompat
import com.example.MainActivity
import com.example.R
import com.example.data.model.Governorate
import com.example.data.model.PrayerTimeItem
import com.example.data.model.PrayerType
import java.time.LocalDate
import java.time.LocalDateTime
import java.time.ZoneId

class AthanNotificationManager(private val context: Context) {

    private val notificationManager =
        context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
    private val alarmManager =
        context.getSystemService(Context.ALARM_SERVICE) as AlarmManager

    companion object {
        const val CHANNEL_ID = "salati_athan_notifications"
        const val CHANNEL_NAME = "أذان صلاتي (Salati Athan)"
        const val EXTRA_PRAYER_NAME = "extra_prayer_name"
        const val EXTRA_GOVERNORATE_NAME = "extra_governorate_name"
        const val ACTION_TRIGGER_ATHAN = "com.example.ACTION_ATHAN_NOTIFICATION"
    }

    init {
        createNotificationChannel()
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val soundUri = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION)
            val audioAttributes = AudioAttributes.Builder()
                .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                .setUsage(AudioAttributes.USAGE_NOTIFICATION_RINGTONE)
                .build()

            val channel = NotificationChannel(
                CHANNEL_ID,
                CHANNEL_NAME,
                NotificationManager.IMPORTANCE_HIGH
            ).apply {
                description = "إشعارات دخول وقت الصلاة والأذان في محافظات العراق"
                enableLights(true)
                enableVibration(true)
                vibrationPattern = longArrayOf(0, 500, 200, 500, 200, 800)
                setSound(soundUri, audioAttributes)
            }
            notificationManager.createNotificationChannel(channel)
        }
    }

    fun showAthanNotification(prayerName: String, governorateName: String) {
        val launchIntent = Intent(context, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
        }
        val pendingIntent = PendingIntent.getActivity(
            context,
            0,
            launchIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val notification = NotificationCompat.Builder(context, CHANNEL_ID)
            .setSmallIcon(R.drawable.img_app_icon)
            .setContentTitle("حان الآن موعد أذان $prayerName")
            .setContentText("في $governorateName - تقبل الله أعمالكم وطاعاتكم")
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setCategory(NotificationCompat.CATEGORY_ALARM)
            .setAutoCancel(true)
            .setContentIntent(pendingIntent)
            .setVibrate(longArrayOf(0, 500, 250, 500, 250, 1000))
            .build()

        notificationManager.notify(System.currentTimeMillis().toInt(), notification)
    }

    fun scheduleAthan(item: PrayerTimeItem, governorate: Governorate, date: LocalDate = LocalDate.now()) {
        if (!item.type.isAthanPrayer) return

        val prayerDateTime = LocalDateTime.of(date, item.time)
        val epochMillis = prayerDateTime.atZone(ZoneId.systemDefault()).toInstant().toEpochMilli()

        if (epochMillis <= System.currentTimeMillis()) {
            return // Passed
        }

        val intent = Intent(context, AthanAlarmReceiver::class.java).apply {
            action = ACTION_TRIGGER_ATHAN
            putExtra(EXTRA_PRAYER_NAME, item.type.arabicName)
            putExtra(EXTRA_GOVERNORATE_NAME, governorate.titleWithSanctity)
        }

        val requestCode = item.type.ordinal + 100
        val pendingIntent = PendingIntent.getBroadcast(
            context,
            requestCode,
            intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                alarmManager.setExactAndAllowWhileIdle(
                    AlarmManager.RTC_WAKEUP,
                    epochMillis,
                    pendingIntent
                )
            } else {
                alarmManager.setExact(
                    AlarmManager.RTC_WAKEUP,
                    epochMillis,
                    pendingIntent
                )
            }
        } catch (e: SecurityException) {
            // Inexact fallback
            alarmManager.set(AlarmManager.RTC_WAKEUP, epochMillis, pendingIntent)
        }
    }
}
