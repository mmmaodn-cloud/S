package com.example.service

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

class AthanAlarmReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val prayerName = intent.getStringExtra(AthanNotificationManager.EXTRA_PRAYER_NAME) ?: "الصلاة"
        val governorateName = intent.getStringExtra(AthanNotificationManager.EXTRA_GOVERNORATE_NAME) ?: "العراق"

        val notificationManager = AthanNotificationManager(context)
        notificationManager.showAthanNotification(prayerName, governorateName)
    }
}
