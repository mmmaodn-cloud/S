package com.example.data.model

import java.time.LocalDate
import java.time.LocalTime
import java.time.format.DateTimeFormatter
import java.time.temporal.ChronoUnit
import kotlin.math.*

enum class PrayerType(
    val id: String,
    val arabicName: String,
    val englishName: String,
    val isAthanPrayer: Boolean
) {
    IMSAK("imsak", "الإمساك", "Imsak", false),
    FAJR("fajr", "الفجر", "Fajr", true),
    SUNRISE("sunrise", "الشروق", "Sunrise", false),
    DHUHR("dhuhr", "الظهر", "Dhuhr", true),
    ASR("asr", "العصر", "Asr", true),
    MAGHRIB("maghrib", "المغرب", "Maghrib", true),
    ISHA("isha", "العشاء", "Isha", true),
    MIDNIGHT("midnight", "منتصف الليل", "Midnight", false)
}

data class PrayerTimeItem(
    val type: PrayerType,
    val time: LocalTime,
    val formattedTime12h: String,
    val isPassed: Boolean = false,
    val isNext: Boolean = false,
    val isNotificationEnabled: Boolean = true
)

data class DayPrayerTimes(
    val date: LocalDate,
    val governorate: Governorate,
    val items: List<PrayerTimeItem>,
    val nextPrayer: PrayerTimeItem?,
    val remainingSecondsToNext: Long
)

object PrayerCalculator {

    // Shia (Jafari / Iraq standard calculation angles)
    private const val FAJR_ANGLE = 16.0
    private const val MAGHRIB_ANGLE = 4.0 // Twilight angle past sunset (disappearance of eastern redness)
    private const val ISHA_ANGLE = 14.0

    fun calculate(date: LocalDate, governorate: Governorate, now: LocalTime = LocalTime.now()): DayPrayerTimes {
        val lat = governorate.latitude
        val lng = governorate.longitude
        val timezone = 3.0 // Iraq UTC+3

        val dayOfYear = date.dayOfYear
        // Solar declination & Equation of time
        val b = 2.0 * Math.PI * (dayOfYear - 81) / 365.0
        val eot = 9.87 * sin(2 * b) - 7.53 * cos(b) - 1.5 * sin(b) // Equation of time in minutes
        val declination = 23.45 * sin(b) // Solar declination in degrees

        // Solar noon (Dhuhr) in fractional hours
        val solarNoon = 12.0 + (timezone * 15.0 - lng) / 15.0 - (eot / 60.0)

        // Helper to compute hour angle for sun altitude alpha
        fun hourAngle(altitude: Double): Double {
            val latRad = Math.toRadians(lat)
            val decRad = Math.toRadians(declination)
            val altRad = Math.toRadians(altitude)
            val cosH = (sin(altRad) - sin(latRad) * sin(decRad)) / (cos(latRad) * cos(decRad))
            val clamped = cosH.coerceIn(-1.0, 1.0)
            return Math.toDegrees(acos(clamped)) / 15.0
        }

        // Sunrise & Sunset angle is approx -0.833° (standard refraction)
        val hSun = hourAngle(-0.833)
        val sunriseHours = solarNoon - hSun
        val sunsetHours = solarNoon + hSun

        // Fajr (16 degrees below horizon)
        val hFajr = hourAngle(-FAJR_ANGLE)
        val fajrHours = solarNoon - hFajr

        // Imsak is ~10 minutes before Fajr
        val imsakHours = fajrHours - (10.0 / 60.0)

        // Asr (Shia: shadow equals height of object plus shadow at noon)
        val noonAltitude = 90.0 - abs(lat - declination)
        val noonShadow = 1.0 / tan(Math.toRadians(noonAltitude))
        val asrAltitude = Math.toDegrees(atan(1.0 / (noonShadow + 1.0)))
        val hAsr = hourAngle(asrAltitude)
        val asrHours = solarNoon + hAsr

        // Maghrib (4 degrees below horizon for clearing of eastern redness)
        val hMaghrib = hourAngle(-MAGHRIB_ANGLE)
        val maghribHours = solarNoon + hMaghrib

        // Isha (14 degrees below horizon)
        val hIsha = hourAngle(-ISHA_ANGLE)
        val ishaHours = solarNoon + hIsha

        // Midnight (Islamic midnight = midpoint between Maghrib and next morning's Fajr)
        // Fajr next day is approximately fajrHours + 24.0
        val midnightHours = (maghribHours + (fajrHours + 24.0)) / 2.0 % 24.0

        fun toLocalTime(fractionalHours: Double): LocalTime {
            var norm = fractionalHours % 24.0
            if (norm < 0) norm += 24.0
            val totalSeconds = (norm * 3600).roundToInt().coerceIn(0, 86399)
            val h = totalSeconds / 3600
            val m = (totalSeconds % 3600) / 60
            val s = totalSeconds % 60
            return LocalTime.of(h, m, s)
        }

        fun format12h(time: LocalTime): String {
            val hour = time.hour
            val minute = time.minute
            val period = if (hour < 12) "ص" else "م"
            val h12 = when {
                hour == 0 -> 12
                hour > 12 -> hour - 12
                else -> hour
            }
            return "%d:%02d %s".format(h12, minute, period)
        }

        val prayerTimesMap = mapOf(
            PrayerType.IMSAK to toLocalTime(imsakHours),
            PrayerType.FAJR to toLocalTime(fajrHours),
            PrayerType.SUNRISE to toLocalTime(sunriseHours),
            PrayerType.DHUHR to toLocalTime(solarNoon),
            PrayerType.ASR to toLocalTime(asrHours),
            PrayerType.MAGHRIB to toLocalTime(maghribHours),
            PrayerType.ISHA to toLocalTime(ishaHours),
            PrayerType.MIDNIGHT to toLocalTime(midnightHours)
        )

        // Determine which prayer is next
        // Consider only the primary prayers: FAJR, SUNRISE, DHUHR, ASR, MAGHRIB, ISHA
        val mainSchedule = listOf(
            PrayerType.FAJR,
            PrayerType.SUNRISE,
            PrayerType.DHUHR,
            PrayerType.ASR,
            PrayerType.MAGHRIB,
            PrayerType.ISHA
        )

        var nextType: PrayerType? = null
        var minRemainingSeconds = Long.MAX_VALUE

        for (type in mainSchedule) {
            val pTime = prayerTimesMap[type]!!
            val diff = ChronoUnit.SECONDS.between(now, pTime)
            if (diff > 0 && diff < minRemainingSeconds) {
                minRemainingSeconds = diff
                nextType = type
            }
        }

        // If all prayers passed today, the next prayer is Fajr tomorrow
        if (nextType == null) {
            nextType = PrayerType.FAJR
            val fajrTime = prayerTimesMap[PrayerType.FAJR]!!
            val secondsUntilMidnight = ChronoUnit.SECONDS.between(now, LocalTime.MAX) + 1
            val secondsFromMidnightToFajr = fajrTime.toSecondOfDay().toLong()
            minRemainingSeconds = secondsUntilMidnight + secondsFromMidnightToFajr
        }

        val items = PrayerType.values().map { type ->
            val pTime = prayerTimesMap[type]!!
            val isPassed = now.isAfter(pTime)
            val isNext = (type == nextType)
            PrayerTimeItem(
                type = type,
                time = pTime,
                formattedTime12h = format12h(pTime),
                isPassed = isPassed,
                isNext = isNext,
                isNotificationEnabled = type.isAthanPrayer
            )
        }

        val nextItem = items.firstOrNull { it.type == nextType }

        return DayPrayerTimes(
            date = date,
            governorate = governorate,
            items = items,
            nextPrayer = nextItem,
            remainingSecondsToNext = minRemainingSeconds.coerceAtLeast(0)
        )
    }

    // Hijri date conversion estimate for Iraq
    fun getHijriDate(date: LocalDate): String {
        // Approximate Hijri algorithm for Iraq calendar
        // Current year 2026: September 2026 is approximately Rabi' al-Awwal 1448 AH
        val julianDay = date.toEpochDay() + 2440588
        var l = julianDay - 1948440 + 10632
        val n = ((l - 1) / 10631).toInt()
        l = l - 10631 * n + 354
        val j = (((10985 - l) / 5316).toInt()) * (((50 * l) / 17719).toInt()) +
                ((l / 5670).toInt()) * (((43 * l) / 15238).toInt())
        l = l - (((30 - j) / 15).toInt()) * (((17719 * j) / 50).toInt()) -
                ((j / 16).toInt()) * (((15238 * j) / 43).toInt()) + 29
        val m = ((24 * l) / 709).toInt()
        val d = l - ((709 * m) / 24).toInt()
        val y = 30 * n + j - 30

        val hijriMonths = listOf(
            "محرم الحرام", "صفر الخير", "ربيع الأول", "ربيع الآخر",
            "جمادى الأولى", "جمادى الآخرة", "رجب الأصب", "شعبان المعظم",
            "شهر رمضان المبارك", "شوال المكرم", "ذو القعدة الحرام", "ذو الحجة الحرام"
        )
        val monthName = hijriMonths.getOrElse(m - 1) { "محرم" }
        return "$d $monthName $y هـ"
    }

    fun getQiblaBearing(governorate: Governorate): Double {
        // Kaaba coordinates: 21.4225° N, 39.8262° E
        val kaabaLat = Math.toRadians(21.4225)
        val kaabaLng = Math.toRadians(39.8262)
        val userLat = Math.toRadians(governorate.latitude)
        val userLng = Math.toRadians(governorate.longitude)

        val deltaLng = kaabaLng - userLng
        val y = sin(deltaLng) * cos(kaabaLat)
        val x = cos(userLat) * sin(kaabaLat) - sin(userLat) * cos(kaabaLat) * cos(deltaLng)
        var bearing = Math.toDegrees(atan2(y, x))
        bearing = (bearing + 360.0) % 360.0
        return (bearing * 10).roundToInt() / 10.0
    }

    fun getDistanceToKaabaKm(governorate: Governorate): Int {
        val r = 6371.0 // Earth radius in km
        val dLat = Math.toRadians(21.4225 - governorate.latitude)
        val dLng = Math.toRadians(39.8262 - governorate.longitude)
        val a = sin(dLat / 2).pow(2) + cos(Math.toRadians(governorate.latitude)) *
                cos(Math.toRadians(21.4225)) * sin(dLng / 2).pow(2)
        val c = 2 * atan2(sqrt(a), sqrt(1 - a))
        return (r * c).roundToInt()
    }
}
