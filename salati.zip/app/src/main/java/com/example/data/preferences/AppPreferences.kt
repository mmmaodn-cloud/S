package com.example.data.preferences

import android.content.Context
import android.content.SharedPreferences

class AppPreferences(context: Context) {
    private val prefs: SharedPreferences =
        context.getSharedPreferences("salati_prefs", Context.MODE_PRIVATE)

    companion object {
        private const val KEY_GOVERNORATE_ID = "pref_governorate_id"
        private const val KEY_NOTIFICATION_PREFIX = "pref_notify_"
        private const val KEY_FAVORITES = "pref_favorite_wallpapers"
    }

    var selectedGovernorateId: String
        get() = prefs.getString(KEY_GOVERNORATE_ID, "karbala") ?: "karbala"
        set(value) = prefs.edit().putString(KEY_GOVERNORATE_ID, value).apply()

    fun isNotificationEnabledForPrayer(prayerId: String): Boolean {
        return prefs.getBoolean(KEY_NOTIFICATION_PREFIX + prayerId, true)
    }

    fun setNotificationEnabledForPrayer(prayerId: String, enabled: Boolean) {
        prefs.edit().putBoolean(KEY_NOTIFICATION_PREFIX + prayerId, enabled).apply()
    }

    fun getFavoriteWallpaperIds(): Set<String> {
        return prefs.getStringSet(KEY_FAVORITES, emptySet()) ?: emptySet()
    }

    fun toggleFavoriteWallpaper(id: String) {
        val current = getFavoriteWallpaperIds().toMutableSet()
        if (current.contains(id)) {
            current.remove(id)
        } else {
            current.add(id)
        }
        prefs.edit().putStringSet(KEY_FAVORITES, current).apply()
    }
}
