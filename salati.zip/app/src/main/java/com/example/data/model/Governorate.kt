package com.example.data.model

data class Governorate(
    val id: String,
    val nameArabic: String,
    val nameEnglish: String,
    val titleWithSanctity: String,
    val latitude: Double,
    val longitude: Double,
    val description: String
)

object IraqGovernorates {
    val list: List<Governorate> = listOf(
        Governorate(
            id = "karbala",
            nameArabic = "كربلاء",
            nameEnglish = "Karbala",
            titleWithSanctity = "كربلاء المقدسة",
            latitude = 32.6160,
            longitude = 44.0249,
            description = "مرقد الإمام الحسين وأبي الفضل العباس (ع)"
        ),
        Governorate(
            id = "najaf",
            nameArabic = "النجف",
            nameEnglish = "Najaf",
            titleWithSanctity = "النجف الأشرف",
            latitude = 32.0259,
            longitude = 44.3462,
            description = "مرقد أمير المؤمنين الإمام علي بن أبي طالب (ع)"
        ),
        Governorate(
            id = "baghdad",
            nameArabic = "بغداد",
            nameEnglish = "Baghdad",
            titleWithSanctity = "بغداد (الكاظمية المقدسة)",
            latitude = 33.3152,
            longitude = 44.3661,
            description = "عاصمة العراق ومرقد الإمامين الكاظمين (ع)"
        ),
        Governorate(
            id = "basra",
            nameArabic = "البصرة",
            nameEnglish = "Basra",
            titleWithSanctity = "البصرة الفيحاء",
            latitude = 30.5081,
            longitude = 47.7835,
            description = "ثغر العراق الباسم وجامع خطوة الإمام علي (ع)"
        ),
        Governorate(
            id = "samarra",
            nameArabic = "صلاح الدين",
            nameEnglish = "Saladin / Samarra",
            titleWithSanctity = "سامراء المقدسة",
            latitude = 34.1983,
            longitude = 43.8742,
            description = "مرقد الإمامين العسكريين (ع)"
        ),
        Governorate(
            id = "babil",
            nameArabic = "بابل",
            nameEnglish = "Babil",
            titleWithSanctity = "بابل (الحلة الفيحاء)",
            latitude = 32.4637,
            longitude = 44.4262,
            description = "مدينة التاريخ ومقام نبي الله إبراهيم (ع)"
        ),
        Governorate(
            id = "dhi_qar",
            nameArabic = "ذي قار",
            nameEnglish = "Dhi Qar",
            titleWithSanctity = "ذي قار (الناصرية)",
            latitude = 31.0580,
            longitude = 46.2573,
            description = "أور التاريخية وموطن الأنبياء والحضارات"
        ),
        Governorate(
            id = "maysan",
            nameArabic = "ميسان",
            nameEnglish = "Maysan",
            titleWithSanctity = "ميسان (العمارة)",
            latitude = 31.8398,
            longitude = 47.1454,
            description = "مدينة الأهوار وعروس دجلة"
        ),
        Governorate(
            id = "wasit",
            nameArabic = "واسط",
            nameEnglish = "Wasit",
            titleWithSanctity = "واسط (الكوت)",
            latitude = 32.5126,
            longitude = 45.8197,
            description = "مدينة الكوت على نهر دجلة الخالد"
        ),
        Governorate(
            id = "diyala",
            nameArabic = "ديالى",
            nameEnglish = "Diyala",
            titleWithSanctity = "ديالى (بعقوبة)",
            latitude = 33.7420,
            longitude = 44.6441,
            description = "مدينة البرتقال وبساتين النخيل"
        ),
        Governorate(
            id = "qadisiyyah",
            nameArabic = "القادسية",
            nameEnglish = "Al-Qadisiyyah",
            titleWithSanctity = "القادسية (الديوانية)",
            latitude = 31.9866,
            longitude = 44.9254,
            description = "قلب الفرات الأوسط"
        ),
        Governorate(
            id = "muthanna",
            nameArabic = "المثنى",
            nameEnglish = "Al-Muthanna",
            titleWithSanctity = "المثنى (السماوة)",
            latitude = 31.3109,
            longitude = 45.2813,
            description = "السماوة وبحيرة ساوة"
        ),
        Governorate(
            id = "kirkuk",
            nameArabic = "كركوك",
            nameEnglish = "Kirkuk",
            titleWithSanctity = "كركوك",
            latitude = 35.4681,
            longitude = 44.3922,
            description = "مدينة القلعة والمحبة والتآخي"
        ),
        Governorate(
            id = "ninawa",
            nameArabic = "نينوى",
            nameEnglish = "Nineveh",
            titleWithSanctity = "نينوى (الموصل الحدباء)",
            latitude = 36.3489,
            longitude = 43.1577,
            description = "أم الربيعين ومقام النبي يونس (ع)"
        ),
        Governorate(
            id = "erbil",
            nameArabic = "أربيل",
            nameEnglish = "Erbil",
            titleWithSanctity = "أربيل (قلعة أربيل)",
            latitude = 36.1901,
            longitude = 44.0091,
            description = "عاصمة إقليم كردستان العراق"
        ),
        Governorate(
            id = "sulaymaniyah",
            nameArabic = "السليمانية",
            nameEnglish = "Sulaymaniyah",
            titleWithSanctity = "السليمانية",
            latitude = 35.5558,
            longitude = 45.4351,
            description = "عروس كردستان وموطن الأدباء"
        ),
        Governorate(
            id = "duhok",
            nameArabic = "دهوك",
            nameEnglish = "Duhok",
            titleWithSanctity = "دهوك",
            latitude = 36.8679,
            longitude = 42.9885,
            description = "شمال العراق الخلاب"
        ),
        Governorate(
            id = "anbar",
            nameArabic = "الأنبار",
            nameEnglish = "Al-Anbar",
            titleWithSanctity = "الأنبار (الرمادي)",
            latitude = 33.4243,
            longitude = 43.2988,
            description = "كبرى محافظات العراق وضفاف الفرات"
        )
    )

    fun getById(id: String): Governorate {
        return list.firstOrNull { it.id == id } ?: list.first()
    }
}
