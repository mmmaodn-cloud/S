package com.example.data.model

import androidx.annotation.DrawableRes
import com.example.R

data class HusainiWallpaper(
    val id: String,
    val title: String,
    val subtitle: String,
    val category: WallpaperCategory,
    @DrawableRes val drawableRes: Int,
    val isFavorite: Boolean = false
)

enum class WallpaperCategory(val arabicTitle: String) {
    ALL("الكل"),
    SHRINES("العتبات المقدسة"),
    BAYN_AL_HARAMAYN("بين الحرمين"),
    CALLIGRAPHY("خط عاشورائي"),
    MUHARRAM("ليالي كربلاء")
}

object WallpaperRepository {
    val wallpapers: List<HusainiWallpaper> = listOf(
        HusainiWallpaper(
            id = "karbala_dome",
            title = "قبة سيد الشهداء (ع)",
            subtitle = "الراية الحمراء والقبة الذهبية في كربلاء المقدسة",
            category = WallpaperCategory.SHRINES,
            drawableRes = R.drawable.img_wallpaper_dome
        ),
        HusainiWallpaper(
            id = "bayn_al_haramayn",
            title = "بين الحرمين الشريفين",
            subtitle = "أقدس مسار بين الروضتين الحسينية والعباسية",
            category = WallpaperCategory.BAYN_AL_HARAMAYN,
            drawableRes = R.drawable.img_wallpaper_bayn
        ),
        HusainiWallpaper(
            id = "ya_hussain_calligraphy",
            title = "نداء يا حسين",
            subtitle = "خط عربي أصيل مرصع بالذهب على خلفية حسينية ملكية",
            category = WallpaperCategory.CALLIGRAPHY,
            drawableRes = R.drawable.img_wallpaper_calligraphy
        ),
        HusainiWallpaper(
            id = "abbas_flag",
            title = "راية قمر بني هاشم (ع)",
            subtitle = "عزة وإباء عند مرقد أبي الفضل العباس عليه السلام",
            category = WallpaperCategory.MUHARRAM,
            drawableRes = R.drawable.img_wallpaper_dome
        ),
        HusainiWallpaper(
            id = "night_in_karbala",
            title = "ليالي كربلاء الروحانية",
            subtitle = "أنوار الضريح المقدس وسكينة الزائرين",
            category = WallpaperCategory.SHRINES,
            drawableRes = R.drawable.img_wallpaper_bayn
        ),
        HusainiWallpaper(
            id = "sacred_karbala_art",
            title = "نقوش العتبة المطهرة",
            subtitle = "زخارف إسلامية فاطمية وحسينية باهرة",
            category = WallpaperCategory.CALLIGRAPHY,
            drawableRes = R.drawable.img_wallpaper_calligraphy
        )
    )
}
