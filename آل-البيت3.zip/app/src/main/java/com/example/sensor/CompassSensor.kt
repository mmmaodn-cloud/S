package com.example.sensor

import android.content.Context
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.sin

class CompassSensor(context: Context) : SensorEventListener {

    private val sensorManager = context.getSystemService(Context.SENSOR_SERVICE) as? SensorManager
    private val accelerometer = sensorManager?.getDefaultSensor(Sensor.TYPE_ACCELEROMETER)
    private val magnetometer = sensorManager?.getDefaultSensor(Sensor.TYPE_MAGNETIC_FIELD)
    private val rotationVector = sensorManager?.getDefaultSensor(Sensor.TYPE_ROTATION_VECTOR)

    private val gravity = FloatArray(3)
    private val geomagnetic = FloatArray(3)
    private val rMat = FloatArray(9)
    private val iMat = FloatArray(9)

    private val _azimuth = MutableStateFlow(0f)
    val azimuth: StateFlow<Float> = _azimuth.asStateFlow()

    private var smoothedAzimuth = 0f

    fun start() {
        if (rotationVector != null) {
            sensorManager?.registerListener(this, rotationVector, SensorManager.SENSOR_DELAY_UI)
        } else {
            sensorManager?.registerListener(this, accelerometer, SensorManager.SENSOR_DELAY_UI)
            sensorManager?.registerListener(this, magnetometer, SensorManager.SENSOR_DELAY_UI)
        }
    }

    fun stop() {
        sensorManager?.unregisterListener(this)
    }

    override fun onSensorChanged(event: SensorEvent?) {
        if (event == null) return

        if (event.sensor.type == Sensor.TYPE_ROTATION_VECTOR) {
            SensorManager.getRotationMatrixFromVector(rMat, event.values)
            val orientation = FloatArray(3)
            SensorManager.getOrientation(rMat, orientation)
            val azimuthRad = orientation[0]
            val deg = Math.toDegrees(azimuthRad.toDouble()).toFloat()
            updateSmoothedAzimuth((deg + 360f) % 360f)
            return
        }

        if (event.sensor.type == Sensor.TYPE_ACCELEROMETER) {
            // Low-pass filter
            gravity[0] = 0.9f * gravity[0] + 0.1f * event.values[0]
            gravity[1] = 0.9f * gravity[1] + 0.1f * event.values[1]
            gravity[2] = 0.9f * gravity[2] + 0.1f * event.values[2]
        }

        if (event.sensor.type == Sensor.TYPE_MAGNETIC_FIELD) {
            geomagnetic[0] = 0.9f * geomagnetic[0] + 0.1f * event.values[0]
            geomagnetic[1] = 0.9f * geomagnetic[1] + 0.1f * event.values[1]
            geomagnetic[2] = 0.9f * geomagnetic[2] + 0.1f * event.values[2]
        }

        val success = SensorManager.getRotationMatrix(rMat, iMat, gravity, geomagnetic)
        if (success) {
            val orientation = FloatArray(3)
            SensorManager.getOrientation(rMat, orientation)
            val azimuthRad = orientation[0]
            val deg = Math.toDegrees(azimuthRad.toDouble()).toFloat()
            updateSmoothedAzimuth((deg + 360f) % 360f)
        }
    }

    private fun updateSmoothedAzimuth(target: Float) {
        // Circular interpolation to prevent jumping across 0/360
        var diff = target - smoothedAzimuth
        while (diff < -180f) diff += 360f
        while (diff > 180f) diff -= 360f
        smoothedAzimuth = (smoothedAzimuth + 0.15f * diff + 360f) % 360f
        _azimuth.value = smoothedAzimuth
    }

    override fun onAccuracyChanged(sensor: Sensor?, accuracy: Int) {}
}
