package com.example.data

import com.example.R

data class HusseiniPhoto(
    val id: String,
    val titleAr: String,
    val titleEn: String,
    val categoryAr: String,
    val localDrawableRes: Int? = null,
    val imageUrl: String,
    val dateAdded: String,
    val isFavorite: Boolean = false,
    val description: String = ""
)

object HusseiniGalleryRepository {

    val initialPhotos = listOf(
        HusseiniPhoto(
            id = "karbala_1",
            titleAr = "قبة الإمام الحسين (ع) الذهبية",
            titleEn = "Golden Dome of Imam Hussain",
            categoryAr = "كربلاء المقدسة",
            localDrawableRes = R.drawable.img_karbala_shrine,
            imageUrl = "https://images.unsplash.com/photo-1564769625905-50e93615e769?auto=format&fit=crop&w=1200&q=80",
            dateAdded = "اليوم - مباشر من كربلاء",
            description = "مشهد مهيب للقبة الشريفة والمنارتين المذهبتين مع الراية الحمراء المباركة"
        ),
        HusseiniPhoto(
            id = "najaf_1",
            titleAr = "حرم أمير المؤمنين علي بن أبي طالب (ع)",
            titleEn = "Holy Shrine of Imam Ali",
            categoryAr = "النجف الأشرف",
            localDrawableRes = R.drawable.img_najaf_shrine,
            imageUrl = "https://images.unsplash.com/photo-1591604466107-ec97de577aff?auto=format&fit=crop&w=1200&q=80",
            dateAdded = "تحديث جديد",
            description = "القبة العلوية المشرفة وإيوان الذهب في النجف الأشرف"
        ),
        HusseiniPhoto(
            id = "abbas_1",
            titleAr = "حرم أبي الفضل العباس (ع) قمر بني هاشم",
            titleEn = "Holy Shrine of Al-Abbas",
            categoryAr = "كربلاء المقدسة",
            imageUrl = "https://images.unsplash.com/photo-1584551246679-0daf3d275d0f?auto=format&fit=crop&w=1200&q=80",
            dateAdded = "محدث أونلاين",
            description = "كفيل زينب وساقي عطاشى كربلاء - باب الحوائج عليه السلام"
        ),
        HusseiniPhoto(
            id = "bayn_alharamayn",
            titleAr = "ساحة بين الحرمين الشريفين ليلاً",
            titleEn = "Bayn al-Haramayn at Night",
            categoryAr = "العتبات المقدسة",
            imageUrl = "https://images.unsplash.com/photo-1542838132-92c53300491e?auto=format&fit=crop&w=1200&q=80",
            dateAdded = "من البث المباشر",
            description = "المسير المبارك بين مرقد سيد الشهداء وأخيه أبي الفضل العباس عليهما السلام"
        ),
        HusseiniPhoto(
            id = "ashura_banner",
            titleAr = "راية لبيك يا حسين الحمراء الخالدة",
            titleEn = "Ya Hussain Red Banner",
            categoryAr = "رايات ومخطوطات",
            imageUrl = "https://images.unsplash.com/photo-1519817650390-64a93db51149?auto=format&fit=crop&w=1200&q=80",
            dateAdded = "خلفية ولائية عالية الدقة",
            description = "شعار الحق والفداء في يوم كربلاء"
        ),
        HusseiniPhoto(
            id = "samarra_shrine",
            titleAr = "حرم الإمامين العسكريين (ع) في سامراء",
            titleEn = "Al-Askari Shrine in Samarra",
            categoryAr = "العتبات المقدسة",
            imageUrl = "https://images.unsplash.com/photo-1578632767115-351597cf2477?auto=format&fit=crop&w=1200&q=80",
            dateAdded = "تحديث المحافظات",
            description = "مرقد الإمام علي الهادي والإمام الحسن العسكري عليهما السلام"
        ),
        HusseiniPhoto(
            id = "kadhimiya_shrine",
            titleAr = "حرم الإمامين الكاظمين (ع) في بغداد",
            titleEn = "Al-Kadhimiya Holy Shrine",
            categoryAr = "العتبات المقدسة",
            imageUrl = "https://images.unsplash.com/photo-1565557623262-b51c2513a641?auto=format&fit=crop&w=1200&q=80",
            dateAdded = "تحديث بغداد",
            description = "مرقد الإمام موسى بن جعفر الكاظم ومحمد بن علي الجواد عليهما السلام"
        ),
        HusseiniPhoto(
            id = "imam_reza",
            titleAr = "حرم ثامن الحجج الإمام علي بن موسى الرضا (ع)",
            titleEn = "Imam Reza Holy Shrine in Mashhad",
            categoryAr = "العتبات المقدسة",
            imageUrl = "https://images.unsplash.com/photo-1596461404969-9ae70f2830c1?auto=format&fit=crop&w=1200&q=80",
            dateAdded = "أنيس النفوس",
            description = "الروضة الرضوية الشريفة في مشهد المقدسة"
        )
    )

    val categories = listOf("الكل", "العتبات المقدسة", "كربلاء المقدسة", "النجف الأشرف", "رايات ومخطوطات")
}
