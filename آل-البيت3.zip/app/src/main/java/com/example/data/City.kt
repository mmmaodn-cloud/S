package com.example.data

data class City(
    val id: String,
    val nameAr: String,
    val nameEn: String,
    val countryAr: String,
    val countryEn: String,
    val latitude: Double,
    val longitude: Double,
    val isIraq: Boolean = true
)

object CityRepository {
    // All 18 Iraqi Governorates (جميع محافظات العراق الـ 18)
    val iraqGovernorates = listOf(
        City("baghdad", "بغداد (العاصمة)", "Baghdad", "العراق", "Iraq", 33.3152, 44.3661, true),
        City("najaf", "النجف الأشرف (حرم الإمام علي ع)", "Najaf", "العراق", "Iraq", 32.0000, 44.3333, true),
        City("karbala", "كربلاء المقدسة (حرم الإمام الحسين ع)", "Karbala", "العراق", "Iraq", 32.6160, 44.0249, true),
        City("basra", "البصرة الفيحاء", "Basra", "العراق", "Iraq", 30.5081, 47.7835, true),
        City("babil", "بابل (الحلة)", "Babil (Hillah)", "العراق", "Iraq", 32.4833, 44.4333, true),
        City("erbil", "أربيل", "Erbil", "العراق", "Iraq", 36.1901, 44.0091, true),
        City("sulaymaniyah", "السليمانية", "Sulaymaniyah", "العراق", "Iraq", 35.5558, 45.4351, true),
        City("duhok", "دهوك", "Duhok", "العراق", "Iraq", 36.8679, 42.9886, true),
        City("kirkuk", "كركوك", "Kirkuk", "العراق", "Iraq", 35.4681, 44.3922, true),
        City("mosul", "نينوى (الموصل)", "Nineveh (Mosul)", "العراق", "Iraq", 36.3400, 43.1300, true),
        City("anbar", "الأنبار (الرمادي)", "Anbar (Ramadi)", "العراق", "Iraq", 33.4244, 43.3000, true),
        City("diyala", "ديالى (بعقوبة)", "Diyala (Baqubah)", "العراق", "Iraq", 33.7450, 44.6442, true),
        City("wasit", "واسط (الكوت)", "Wasit (Kut)", "العراق", "Iraq", 32.5126, 45.8197, true),
        City("maysan", "ميسان (العمارة)", "Maysan (Amarah)", "العراق", "Iraq", 31.8419, 47.1450, true),
        City("dhiqar", "ذي قار (الناصرية)", "Dhi Qar (Nasiriyah)", "العراق", "Iraq", 31.0500, 46.2600, true),
        City("muthanna", "المثنى (السماوة)", "Muthanna (Samawah)", "العراق", "Iraq", 31.3167, 45.2833, true),
        City("diwaniyah", "القادسية (الديوانية)", "Qadisiyyah (Diwaniyah)", "العراق", "Iraq", 31.9922, 44.9211, true),
        City("samarra", "صلاح الدين (سامراء - حرم العسكريين ع)", "Salah al-Din (Samarra)", "العراق", "Iraq", 34.1983, 43.8742, true)
    )

    // Other Islamic Holy Shrines & Global Cities (دول وعواصم العالم)
    val worldCities = listOf(
        City("mashhad", "مشهد المقدسة (حرم الإمام الرضا ع)", "Mashhad", "إيران", "Iran", 36.2972, 59.6067, false),
        City("qom", "قم المقدسة (حرم السيدة معصومة ع)", "Qom", "إيران", "Iran", 34.6401, 50.8764, false),
        City("tehran", "طهران", "Tehran", "إيران", "Iran", 35.6892, 51.3890, false),
        City("makkah", "مكة المكرمة (بيت الله الحرام)", "Makkah", "السعودية", "Saudi Arabia", 21.4225, 39.8262, false),
        City("madinah", "المدينة المنورة (حرم النبي وأئمة البقيع ع)", "Madinah", "السعودية", "Saudi Arabia", 24.5247, 39.5692, false),
        City("qatif", "القطيف", "Qatif", "السعودية", "Saudi Arabia", 26.5652, 50.0097, false),
        City("ahsa", "الأحساء", "Al-Ahsa", "السعودية", "Saudi Arabia", 25.3833, 49.5833, false),
        City("damascus", "دمشق (حرم السيدة زينب ورقية ع)", "Damascus", "سوريا", "Syria", 33.5138, 36.2765, false),
        City("beirut", "بيروت", "Beirut", "لبنان", "Lebanon", 33.8938, 35.5018, false),
        City("kuwait", "الكويت", "Kuwait City", "الكويت", "Kuwait", 29.3759, 47.9774, false),
        City("manama", "المنامة", "Manama", "البحرين", "Bahrain", 26.2285, 50.5860, false),
        City("muscat", "مسقط", "Muscat", "عُمان", "Oman", 23.5859, 58.4059, false),
        City("dubai", "دبي", "Dubai", "الإمارات", "UAE", 25.2048, 55.2708, false),
        City("cairo", "القاهرة (حرم الإمام الحسين ع)", "Cairo", "مصر", "Egypt", 30.0444, 31.2357, false),
        City("istanbul", "إسطنبول", "Istanbul", "تركيا", "Turkey", 41.0082, 28.9784, false),
        City("london", "لندن", "London", "المملكة المتحدة", "UK", 51.5074, -0.1278, false),
        City("dearborn", "ديربورن / ميشيغان", "Dearborn", "الولايات المتحدة", "USA", 42.3223, -83.1763, false),
        City("stockholm", "ستوكهولم", "Stockholm", "السويد", "Sweden", 59.3293, 18.0686, false),
        City("berlin", "برلين", "Berlin", "ألمانيا", "Germany", 52.5200, 13.4050, false)
    )

    val allCities = iraqGovernorates + worldCities

    fun getCityById(id: String): City {
        return allCities.firstOrNull { it.id == id } ?: iraqGovernorates[1] // Default: Najaf Ashraf
    }
}
