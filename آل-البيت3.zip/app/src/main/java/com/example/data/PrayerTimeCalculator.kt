package com.example.data

import java.util.Calendar
import java.util.Date
import java.util.TimeZone
import kotlin.math.*

data class PrayerTimes(
    val imsak: String,
    val fajr: String,
    val sunrise: String,
    val dhuhr: String,
    val asr: String,
    val sunset: String,
    val maghrib: String,
    val isha: String,
    val midnight: String,
    val nextPrayerNameAr: String,
    val nextPrayerNameEn: String,
    val nextPrayerRemainingFormatted: String,
    val nextPrayerProgress: Float // 0f to 1f
)

object PrayerTimeCalculator {

    private const val KAABA_LAT = 21.422477
    private const val KAABA_LNG = 39.826168

    // Shia Ithna Ashari parameters (معهد لواء / جامعة طهران / الشيعة الإمامية)
    private const val FAJR_ANGLE = 16.0
    private const val MAGHRIB_ANGLE = 4.0
    private const val ISHA_ANGLE = 14.0
    private const val IMSAK_ANGLE = 18.0

    fun calculateQibla(latitude: Double, longitude: Double): Double {
        val latRad = Math.toRadians(latitude)
        val lngRad = Math.toRadians(longitude)
        val kLatRad = Math.toRadians(KAABA_LAT)
        val kLngRad = Math.toRadians(KAABA_LNG)

        val deltaLng = kLngRad - lngRad
        val y = sin(deltaLng) * cos(kLatRad)
        val x = cos(latRad) * sin(kLatRad) - sin(latRad) * cos(kLatRad) * cos(deltaLng)

        var qibla = Math.toDegrees(atan2(y, x))
        qibla = (qibla + 360.0) % 360.0
        return qibla
    }

    fun calculateTimes(city: City, date: Date = Date(), offsetMinutes: Int = 0): PrayerTimes {
        val cal = Calendar.getInstance(TimeZone.getDefault())
        cal.time = date

        val year = cal.get(Calendar.YEAR)
        val month = cal.get(Calendar.MONTH) + 1
        val day = cal.get(Calendar.DAY_OF_MONTH)
        val timeZone = TimeZone.getDefault().getOffset(date.time) / 3600000.0

        // Julian Date
        val jd = julianDate(year, month, day) - city.longitude / (360.0 * 24.0)

        // Solar coordinates
        val d = jd - 2451545.0
        val g = fixAngle(357.529 + 0.98560028 * d)
        val q = fixAngle(280.459 + 0.98564736 * d)
        val l = fixAngle(q + 1.915 * sin(Math.toRadians(g)) + 0.020 * sin(Math.toRadians(2 * g)))

        val e = 23.439 - 0.00000036 * d
        val ra = Math.toDegrees(atan2(cos(Math.toRadians(e)) * sin(Math.toRadians(l)), cos(Math.toRadians(l)))) / 15.0
        val delta = Math.toDegrees(asin(sin(Math.toRadians(e)) * sin(Math.toRadians(l)))) // Declination

        // Equation of Time
        val eqt = q / 15.0 - fixHour(ra)

        // Midday (Dhuhr)
        val noon = fixHour(12.0 + timeZone - city.longitude / 15.0 - eqt)

        // Sun angles for Shia prayers
        val imsakT = noon - hourAngle(IMSAK_ANGLE, delta, city.latitude)
        val fajrT = noon - hourAngle(FAJR_ANGLE, delta, city.latitude)
        val sunriseT = noon - hourAngle(0.833, delta, city.latitude)
        val sunsetT = noon + hourAngle(0.833, delta, city.latitude)
        val maghribT = noon + hourAngle(MAGHRIB_ANGLE, delta, city.latitude)
        val ishaT = noon + hourAngle(ISHA_ANGLE, delta, city.latitude)

        // Shia Asr (Shafi/Shia shadow equation)
        val asrAngle = -Math.toDegrees(atan(1.0 + tan(Math.toRadians(abs(city.latitude - delta)))))
        val asrT = noon + hourAngle(-asrAngle, delta, city.latitude)

        // Midnight in Shia jurisprudence: Middle between Maghrib and the next morning's Fajr
        // (Maghrib + (Fajr + 24 - Maghrib) / 2)
        val fajrNext = fajrT + 24.0
        val midnightT = fixHour(maghribT + (fajrNext - maghribT) / 2.0)

        val imsakStr = formatTime(imsakT, offsetMinutes)
        val fajrStr = formatTime(fajrT, offsetMinutes)
        val sunriseStr = formatTime(sunriseT, offsetMinutes)
        val dhuhrStr = formatTime(noon, offsetMinutes)
        val asrStr = formatTime(asrT, offsetMinutes)
        val sunsetStr = formatTime(sunsetT, offsetMinutes)
        val maghribStr = formatTime(maghribT, offsetMinutes)
        val ishaStr = formatTime(ishaT, offsetMinutes)
        val midnightStr = formatTime(midnightT, offsetMinutes)

        // Calculate next prayer countdown
        val currentHour = cal.get(Calendar.HOUR_OF_DAY) + cal.get(Calendar.MINUTE) / 60.0 + cal.get(Calendar.SECOND) / 3600.0

        val prayerList = listOf(
            Triple("الإمساك", "Imsak", imsakT),
            Triple("الفجر", "Fajr", fajrT),
            Triple("الشروق", "Sunrise", sunriseT),
            Triple("الظهر", "Dhuhr", noon),
            Triple("العصر", "Asr", asrT),
            Triple("المغرب", "Maghrib", maghribT),
            Triple("العشاء", "Isha", ishaT),
            Triple("منتصف الليل", "Midnight", midnightT)
        )

        var nextNameAr = "الإمساك"
        var nextNameEn = "Imsak"
        var diffHours = 0.0
        var totalInterval = 4.0

        val upcoming = prayerList.firstOrNull { it.third > currentHour }
        if (upcoming != null) {
            nextNameAr = upcoming.first
            nextNameEn = upcoming.second
            diffHours = upcoming.third - currentHour
        } else {
            // Next is tomorrow's Imsak
            nextNameAr = "الإمساك غداً"
            nextNameEn = "Imsak Tomorrow"
            diffHours = (imsakT + 24.0) - currentHour
        }

        val totalMinutes = (diffHours * 60).toInt().coerceAtLeast(0)
        val remH = totalMinutes / 60
        val remM = totalMinutes % 60
        val remFormatted = if (remH > 0) "$remH س $remM د" else "$remM دقيقة"
        val progress = (1f - (diffHours.toFloat() / 6f)).coerceIn(0.05f, 0.95f)

        return PrayerTimes(
            imsak = imsakStr,
            fajr = fajrStr,
            sunrise = sunriseStr,
            dhuhr = dhuhrStr,
            asr = asrStr,
            sunset = sunsetStr,
            maghrib = maghribStr,
            isha = ishaStr,
            midnight = midnightStr,
            nextPrayerNameAr = nextNameAr,
            nextPrayerNameEn = nextNameEn,
            nextPrayerRemainingFormatted = remFormatted,
            nextPrayerProgress = progress
        )
    }

    private fun hourAngle(alpha: Double, delta: Double, lat: Double): Double {
        val cosH = (sin(Math.toRadians(-alpha)) - sin(Math.toRadians(lat)) * sin(Math.toRadians(delta))) /
                (cos(Math.toRadians(lat)) * cos(Math.toRadians(delta)))
        val clamped = cosH.coerceIn(-1.0, 1.0)
        return Math.toDegrees(acos(clamped)) / 15.0
    }

    private fun julianDate(year: Int, month: Int, day: Int): Double {
        var y = year
        var m = month
        if (m <= 2) {
            y -= 1
            m += 12
        }
        val a = floor(y / 100.0)
        val b = 2 - a + floor(a / 4.0)
        return floor(365.25 * (y + 4716)) + floor(30.6001 * (m + 1)) + day + b - 1524.5
    }

    private fun fixAngle(angle: Double): Double = (angle % 360.0 + 360.0) % 360.0
    private fun fixHour(hour: Double): Double = (hour % 24.0 + 24.0) % 24.0

    private fun formatTime(hourDouble: Double, offsetMinutes: Int): String {
        val totalMinutes = (fixHour(hourDouble) * 60 + offsetMinutes).toInt()
        val h = (totalMinutes / 60) % 24
        val m = totalMinutes % 60
        return String.format("%02d:%02d", h, m)
    }
}
