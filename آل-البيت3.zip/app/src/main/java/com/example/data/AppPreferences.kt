package com.example.data

import android.content.Context
import android.content.SharedPreferences

class AppPreferences(context: Context) {
    private val prefs: SharedPreferences =
        context.getSharedPreferences("ahl_al_bayt_prefs", Context.MODE_PRIVATE)

    companion object {
        private const val KEY_CITY_ID = "selected_city_id"
        private const val KEY_DARK_MODE = "dark_mode_enabled"
        private const val KEY_LANGUAGE = "app_language"
        private const val KEY_MUADHIN_ID = "selected_muadhin_id"
        private const val KEY_CUSTOM_TONE_URI = "custom_tone_uri"
        private const val KEY_CUSTOM_TONE_NAME = "custom_tone_name"
        private const val KEY_TASBEEH_TOTAL = "tasbeeh_lifetime_total"
        private const val KEY_TASBEEH_CURRENT = "tasbeeh_current_count"
        private const val KEY_NOTIFY_FAJR = "notify_fajr"
        private const val KEY_NOTIFY_DHUHR = "notify_dhuhr"
        private const val KEY_NOTIFY_MAGHRIB = "notify_maghrib"
    }

    var selectedCityId: String
        get() = prefs.getString(KEY_CITY_ID, "najaf") ?: "najaf"
        set(value) = prefs.edit().putString(KEY_CITY_ID, value).apply()

    var isDarkMode: Boolean
        get() = prefs.getBoolean(KEY_DARK_MODE, true) // Default luxurious dark
        set(value) = prefs.edit().putBoolean(KEY_DARK_MODE, value).apply()

    var language: String
        get() = prefs.getString(KEY_LANGUAGE, "ar") ?: "ar"
        set(value) = prefs.edit().putString(KEY_LANGUAGE, value).apply()

    var muadhinId: String
        get() = prefs.getString(KEY_MUADHIN_ID, "najaf") ?: "najaf"
        set(value) = prefs.edit().putString(KEY_MUADHIN_ID, value).apply()

    var customToneUri: String?
        get() = prefs.getString(KEY_CUSTOM_TONE_URI, null)
        set(value) = prefs.edit().putString(KEY_CUSTOM_TONE_URI, value).apply()

    var customToneName: String
        get() = prefs.getString(KEY_CUSTOM_TONE_NAME, "نغمة الاستوديو المخصصة") ?: "نغمة الاستوديو المخصصة"
        set(value) = prefs.edit().putString(KEY_CUSTOM_TONE_NAME, value).apply()

    var tasbeehTotalCount: Long
        get() = prefs.getLong(KEY_TASBEEH_TOTAL, 0L)
        set(value) = prefs.edit().putLong(KEY_TASBEEH_TOTAL, value).apply()

    var tasbeehCurrentCount: Int
        get() = prefs.getInt(KEY_TASBEEH_CURRENT, 0)
        set(value) = prefs.edit().putInt(KEY_TASBEEH_CURRENT, value).apply()

    var notifyFajr: Boolean
        get() = prefs.getBoolean(KEY_NOTIFY_FAJR, true)
        set(value) = prefs.edit().putBoolean(KEY_NOTIFY_FAJR, value).apply()

    var notifyDhuhr: Boolean
        get() = prefs.getBoolean(KEY_NOTIFY_DHUHR, true)
        set(value) = prefs.edit().putBoolean(KEY_NOTIFY_DHUHR, value).apply()

    var notifyMaghrib: Boolean
        get() = prefs.getBoolean(KEY_NOTIFY_MAGHRIB, true)
        set(value) = prefs.edit().putBoolean(KEY_NOTIFY_MAGHRIB, value).apply()
}
