package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.animation.Crossfade
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Mosque
import androidx.compose.material.icons.filled.VolumeUp
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.audio.AdhanManager
import com.example.data.AppPreferences
import com.example.data.CityRepository
import com.example.ui.navigation.AppScreen
import com.example.ui.screens.*
import com.example.ui.theme.AhlAlBaytTheme
import com.example.ui.theme.EmeraldPrimary
import com.example.ui.theme.GoldLight
import com.example.ui.theme.GoldPrimary
import com.example.ui.theme.GoldSecondary
import com.example.ui.theme.KarbalaRed
import java.text.SimpleDateFormat
import java.util.*

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        val appPrefs = AppPreferences(applicationContext)

        // Restore custom Adhan tone if saved
        appPrefs.customToneUri?.let { uriStr ->
            AdhanManager.setCustomUri(android.net.Uri.parse(uriStr), appPrefs.customToneName)
        }
        AdhanManager.setMuadhin(appPrefs.muadhinId)

        setContent {
            var isDarkMode by remember { mutableStateOf(appPrefs.isDarkMode) }
            var currentLanguage by remember { mutableStateOf(appPrefs.language) }
            var currentCity by remember {
                mutableStateOf(CityRepository.getCityById(appPrefs.selectedCityId))
            }
            var currentScreen by remember { mutableStateOf(AppScreen.PRAYERS) }

            val isArabic = currentLanguage == "ar"

            AhlAlBaytTheme(darkTheme = isDarkMode) {
                Scaffold(
                    modifier = Modifier.fillMaxSize(),
                    topBar = {
                        AhlAlBaytTopBar(
                            isArabic = isArabic,
                            onOpenSettings = { currentScreen = AppScreen.SETTINGS }
                        )
                    },
                    bottomBar = {
                        AhlAlBaytBottomBar(
                            currentScreen = currentScreen,
                            onScreenSelected = { currentScreen = it },
                            isArabic = isArabic
                        )
                    }
                ) { innerPadding ->
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(innerPadding)
                    ) {
                        Crossfade(targetState = currentScreen, label = "screen_fade") { screen ->
                            when (screen) {
                                AppScreen.PRAYERS -> PrayersScreen(
                                    currentCity = currentCity,
                                    onCitySelected = {
                                        currentCity = it
                                        appPrefs.selectedCityId = it.id
                                    },
                                    isArabic = isArabic
                                )
                                AppScreen.QIBLA -> QiblaScreen(
                                    currentCity = currentCity,
                                    isArabic = isArabic
                                )
                                AppScreen.TASBEEH -> TasbeehScreen(
                                    appPrefs = appPrefs,
                                    isArabic = isArabic
                                )
                                AppScreen.QURAN -> QuranScreen(
                                    isArabic = isArabic
                                )
                                AppScreen.GALLERY -> GalleryScreen(
                                    isArabic = isArabic
                                )
                                AppScreen.SETTINGS -> SettingsScreen(
                                    appPrefs = appPrefs,
                                    currentCity = currentCity,
                                    onCityChanged = { currentCity = it },
                                    isDarkMode = isDarkMode,
                                    onDarkModeChanged = { isDarkMode = it },
                                    currentLanguage = currentLanguage,
                                    onLanguageChanged = { currentLanguage = it }
                                )
                            }
                        }
                    }
                }
            }
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        AdhanManager.stopAdhan()
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AhlAlBaytTopBar(
    isArabic: Boolean,
    onOpenSettings: () -> Unit
) {
    val isPlayingAdhan by AdhanManager.isPlaying.collectAsState()
    val todayDateFormatted = remember {
        val sdf = SimpleDateFormat("EEEE, d MMMM yyyy", Locale("ar"))
        sdf.format(Date())
    }

    TopAppBar(
        title = {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    modifier = Modifier
                        .size(36.dp)
                        .clip(CircleShape)
                        .background(EmeraldPrimary)
                        .border(1.dp, GoldPrimary, CircleShape),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.Mosque,
                        contentDescription = "Ahl Al Bayt",
                        tint = GoldLight,
                        modifier = Modifier.size(20.dp)
                    )
                }
                Spacer(modifier = Modifier.width(10.dp))
                Column {
                    Text(
                        text = if (isArabic) "آل البيت (ع)" else "Ahl Al-Bayt",
                        fontWeight = FontWeight.ExtraBold,
                        fontSize = 18.sp,
                        color = GoldSecondary
                    )
                    Text(
                        text = todayDateFormatted,
                        fontSize = 10.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        },
        actions = {
            if (isPlayingAdhan) {
                Surface(
                    shape = RoundedCornerShape(12.dp),
                    color = KarbalaRed,
                    modifier = Modifier.padding(end = 8.dp)
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = Icons.Default.VolumeUp,
                            contentDescription = "Playing",
                            tint = Color.White,
                            modifier = Modifier.size(14.dp)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = if (isArabic) "الأذان يرتفع" else "Adhan Active",
                            color = Color.White,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }
        },
        colors = TopAppBarDefaults.topAppBarColors(
            containerColor = MaterialTheme.colorScheme.surface
        )
    )
}

@Composable
fun AhlAlBaytBottomBar(
    currentScreen: AppScreen,
    onScreenSelected: (AppScreen) -> Unit,
    isArabic: Boolean
) {
    NavigationBar(
        containerColor = MaterialTheme.colorScheme.surface,
        contentColor = GoldPrimary,
        tonalElevation = 8.dp
    ) {
        AppScreen.values().forEach { screen ->
            val isSelected = currentScreen == screen
            NavigationBarItem(
                selected = isSelected,
                onClick = { onScreenSelected(screen) },
                icon = {
                    Icon(
                        imageVector = screen.icon,
                        contentDescription = screen.titleAr,
                        modifier = Modifier.size(22.dp)
                    )
                },
                label = {
                    Text(
                        text = if (isArabic) screen.titleAr else screen.titleEn,
                        fontSize = 10.sp,
                        fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal
                    )
                },
                colors = NavigationBarItemDefaults.colors(
                    selectedIconColor = Color.Black,
                    selectedTextColor = GoldSecondary,
                    indicatorColor = GoldPrimary,
                    unselectedIconColor = MaterialTheme.colorScheme.onSurfaceVariant,
                    unselectedTextColor = MaterialTheme.colorScheme.onSurfaceVariant
                )
            )
        }
    }
}
