package com.example.audio

import android.content.Context
import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioTrack
import android.media.MediaPlayer
import android.net.Uri
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import kotlin.math.sin

data class Muadhin(
    val id: String,
    val nameAr: String,
    val nameEn: String,
    val shrine: String,
    val isCustom: Boolean = false
)

object AdhanManager {
    val muadhins = listOf(
        Muadhin("najaf", "أذان العتبة العلوية المقدسة", "Imam Ali Holy Shrine", "النجف الأشرف"),
        Muadhin("karbala", "أذان العتبة الحسينية المقدسة", "Imam Hussain Holy Shrine", "كربلاء المقدسة"),
        Muadhin("maytham", "أذان الحاج ميثم التمار", "Maytham Al-Tamar", "العراق"),
        Muadhin("halwaji", "أذان أبا ذر الحلواجي", "Aba Thar Al-Halwaji", "البحرين"),
        Muadhin("akraf", "أذان الشيخ حسين الأكرف", "Hussein Al-Akraf", "البحرين"),
        Muadhin("custom", "نغمة أذان مخصصة من الاستوديو", "Custom Tone from Studio", "ملف صوتي شخصي", isCustom = true)
    )

    val shiaAdhanPhrases = listOf(
        "اللهُ أَكْبَرُ • اللهُ أَكْبَرُ",
        "اللهُ أَكْبَرُ • اللهُ أَكْبَرُ",
        "أَشْهَدُ أَنْ لَا إِلٰهَ إِلَّا اللهُ (مرتان)",
        "أَشْهَدُ أَنَّ مُحَمَّداً رَسُولُ اللهِ (مرتان)",
        "أَشْهَدُ أَنَّ عَلِيّاً وَلِيُّ اللهِ (مرتان)",
        "حَيَّ عَلَى الصَّلَاةِ (مرتان)",
        "حَيَّ عَلَى الْفَلَاحِ (مرتان)",
        "حَيَّ عَلَى خَيْرِ الْعَمَلِ (مرتان)",
        "اللهُ أَكْبَرُ • اللهُ أَكْبَرُ",
        "لَا إِلٰهَ إِلَّا اللهُ (مرتان)"
    )

    private var mediaPlayer: MediaPlayer? = null
    private var synthJob: Job? = null
    private var audioTrack: AudioTrack? = null

    private val _isPlaying = MutableStateFlow(false)
    val isPlaying: StateFlow<Boolean> = _isPlaying.asStateFlow()

    private val _currentPhraseIndex = MutableStateFlow(0)
    val currentPhraseIndex: StateFlow<Int> = _currentPhraseIndex.asStateFlow()

    private val _currentMuadhinId = MutableStateFlow("najaf")
    val currentMuadhinId: StateFlow<String> = _currentMuadhinId.asStateFlow()

    private val _customUriString = MutableStateFlow<String?>(null)
    val customUriString: StateFlow<String?> = _customUriString.asStateFlow()

    private val _customToneName = MutableStateFlow<String?>("لم يتم اختيار نغمة بعد")
    val customToneName: StateFlow<String?> = _customToneName.asStateFlow()

    fun setMuadhin(id: String) {
        _currentMuadhinId.value = id
    }

    fun setCustomUri(uri: Uri, name: String) {
        _customUriString.value = uri.toString()
        _customToneName.value = name
        _currentMuadhinId.value = "custom"
    }

    fun playAdhan(context: Context, scope: CoroutineScope) {
        stopAdhan()
        _isPlaying.value = true

        val customUri = _customUriString.value
        if (_currentMuadhinId.value == "custom" && customUri != null) {
            try {
                mediaPlayer = MediaPlayer().apply {
                    setDataSource(context, Uri.parse(customUri))
                    setOnCompletionListener {
                        _isPlaying.value = false
                        _currentPhraseIndex.value = 0
                    }
                    prepare()
                    start()
                }
                // Animate phrases during playback
                synthJob = scope.launch(Dispatchers.Default) {
                    for (i in shiaAdhanPhrases.indices) {
                        if (!_isPlaying.value) break
                        _currentPhraseIndex.value = i
                        kotlinx.coroutines.delay(4000)
                    }
                }
                return
            } catch (e: Exception) {
                // fallback to synthesizer
            }
        }

        // Harmonious Islamic Adhan Melody Synthesizer (Maqam Rast / Bayati spiritual notes)
        synthJob = scope.launch(Dispatchers.Default) {
            try {
                playHarmonicAdhanSequence()
            } catch (e: Exception) {
                // ignore
            } finally {
                _isPlaying.value = false
                _currentPhraseIndex.value = 0
            }
        }
    }

    fun stopAdhan() {
        _isPlaying.value = false
        synthJob?.cancel()
        synthJob = null
        try {
            mediaPlayer?.stop()
            mediaPlayer?.release()
        } catch (e: Exception) {}
        mediaPlayer = null

        try {
            audioTrack?.stop()
            audioTrack?.release()
        } catch (e: Exception) {}
        audioTrack = null
    }

    // High quality sine audio synthesizer producing calm Islamic tones (Bayati/Rast scales)
    private suspend fun playHarmonicAdhanSequence() {
        val sampleRate = 22050
        val minBufferSize = AudioTrack.getMinBufferSize(
            sampleRate,
            AudioFormat.CHANNEL_OUT_MONO,
            AudioFormat.ENCODING_PCM_16BIT
        )
        audioTrack = AudioTrack.Builder()
            .setAudioAttributes(
                AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_MEDIA)
                    .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
                    .build()
            )
            .setAudioFormat(
                AudioFormat.Builder()
                    .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                    .setSampleRate(sampleRate)
                    .setChannelMask(AudioFormat.CHANNEL_OUT_MONO)
                    .build()
            )
            .setBufferSizeInBytes(minBufferSize.coerceAtLeast(4096))
            .build()

        audioTrack?.play()

        // Authentic resonant scale: D4 (293.66), E4 (329.63), F4 (349.23), G4 (392.00), A4 (440.00), C5 (523.25)
        val melody = listOf(
            listOf(293.66, 349.23, 392.0), // Allahu Akbar
            listOf(392.0, 440.0, 392.0),
            listOf(349.23, 392.0, 440.0, 392.0), // Ashhadu an La Ilaha Illallah
            listOf(293.66, 349.23, 392.0, 440.0), // Ashhadu anna Muhammadan Rasulullah
            listOf(440.0, 523.25, 440.0, 392.0), // Ashhadu anna Aliyan Waliyyullah
            listOf(392.0, 349.23, 293.66), // Hayya 'Ala Salah
            listOf(349.23, 392.0, 440.0), // Hayya 'Ala Falah
            listOf(440.0, 523.25, 440.0, 349.23, 293.66), // Hayya 'Ala Khayr Al-Amal
            listOf(293.66, 349.23, 392.0), // Allahu Akbar
            listOf(293.66, 293.66) // La Ilaha Illallah
        )

        for (phraseIdx in melody.indices) {
            if (!_isPlaying.value) break
            _currentPhraseIndex.value = phraseIdx
            val notes = melody[phraseIdx]
            for (freq in notes) {
                if (!_isPlaying.value) break
                val durationMs = 700
                val numSamples = (sampleRate * durationMs) / 1000
                val buffer = ShortArray(numSamples)
                for (i in 0 until numSamples) {
                    val time = i.toDouble() / sampleRate
                    // Sine with gentle envelope
                    val envelope = sin(Math.PI * (i.toDouble() / numSamples))
                    val sample = (sin(2.0 * Math.PI * freq * time) * 0.6 * envelope * Short.MAX_VALUE).toInt().toShort()
                    buffer[i] = sample
                }
                audioTrack?.write(buffer, 0, buffer.size)
                kotlinx.coroutines.delay(100)
            }
            kotlinx.coroutines.delay(400)
        }
    }
}
