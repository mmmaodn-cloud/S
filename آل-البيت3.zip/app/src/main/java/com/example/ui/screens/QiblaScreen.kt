package com.example.ui.screens

import android.content.Context
import android.os.Build
import android.os.VibrationEffect
import android.os.Vibrator
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.CompassCalibration
import androidx.compose.material.icons.filled.LocationOn
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.City
import com.example.data.PrayerTimeCalculator
import com.example.sensor.CompassSensor
import com.example.ui.theme.*
import kotlin.math.*

@Composable
fun QiblaScreen(
    currentCity: City,
    isArabic: Boolean = true
) {
    val context = LocalContext.current
    val compassSensor = remember { CompassSensor(context) }
    val currentAzimuth by compassSensor.azimuth.collectAsState()

    DisposableEffect(Unit) {
        compassSensor.start()
        onDispose { compassSensor.stop() }
    }

    val qiblaAngle = remember(currentCity) {
        PrayerTimeCalculator.calculateQibla(currentCity.latitude, currentCity.longitude).toFloat()
    }

    // Relative angle between device heading and Qibla:
    // (qiblaAngle - currentAzimuth)
    var deltaAngle = (qiblaAngle - currentAzimuth) % 360f
    if (deltaAngle < 0) deltaAngle += 360f

    val isAligned = deltaAngle in 356f..360f || deltaAngle in 0f..4f

    // Trigger gentle haptic vibration once when entering alignment
    val vibrator = remember {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            context.getSystemService(Context.VIBRATOR_MANAGER_SERVICE) as? android.os.VibratorManager
        } else {
            @Suppress("DEPRECATION")
            context.getSystemService(Context.VIBRATOR_SERVICE) as? Vibrator
        }
    }

    LaunchedEffect(isAligned) {
        if (isAligned) {
            try {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                    (context.getSystemService(Context.VIBRATOR_SERVICE) as? Vibrator)?.vibrate(
                        VibrationEffect.createOneShot(40, VibrationEffect.DEFAULT_AMPLITUDE)
                    )
                }
            } catch (e: Exception) {}
        }
    }

    val animatedDialRotation by animateFloatAsState(
        targetValue = -currentAzimuth,
        animationSpec = spring(dampingRatio = 0.8f, stiffness = 400f),
        label = "dial_rot"
    )

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.SpaceBetween
    ) {
        // City & Target Info Card
        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(14.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.LocationOn,
                        contentDescription = "City",
                        tint = GoldPrimary,
                        modifier = Modifier.size(20.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Column {
                        Text(
                            text = if (isArabic) currentCity.nameAr else currentCity.nameEn,
                            fontWeight = FontWeight.Bold,
                            fontSize = 15.sp,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                        Text(
                            text = if (isArabic) "زاوية القبلة: ${qiblaAngle.roundToInt()}°" else "Qibla: ${qiblaAngle.roundToInt()}°",
                            fontSize = 12.sp,
                            color = GoldDark
                        )
                    }
                }

                Surface(
                    shape = RoundedCornerShape(10.dp),
                    color = if (isAligned) EmeraldPrimary else MaterialTheme.colorScheme.surfaceVariant
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        if (isAligned) {
                            Icon(
                                imageVector = Icons.Default.CheckCircle,
                                contentDescription = "Aligned",
                                tint = GoldLight,
                                modifier = Modifier.size(16.dp)
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                        }
                        Text(
                            text = if (isAligned) (if (isArabic) "باتجاه الكعبة" else "Aligned")
                            else "${deltaAngle.roundToInt()}°",
                            fontWeight = FontWeight.Bold,
                            fontSize = 13.sp,
                            color = if (isAligned) Color.White else MaterialTheme.colorScheme.onSurface
                        )
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(10.dp))

        // Compass Dial Container
        Box(
            modifier = Modifier
                .size(310.dp)
                .clip(CircleShape)
                .background(
                    Brush.radialGradient(
                        colors = listOf(
                            MaterialTheme.colorScheme.surfaceVariant,
                            DarkCanvas
                        )
                    )
                )
                .border(
                    width = if (isAligned) 4.dp else 2.dp,
                    brush = Brush.sweepGradient(
                        listOf(
                            if (isAligned) GoldLight else EmeraldPrimary,
                            GoldPrimary,
                            if (isAligned) GoldGlow else EmeraldMedium,
                            if (isAligned) GoldLight else EmeraldPrimary
                        )
                    ),
                    shape = CircleShape
                ),
            contentAlignment = Alignment.Center
        ) {
            // Rotating Compass Compass Dial
            Canvas(
                modifier = Modifier
                    .fillMaxSize()
                    .rotate(animatedDialRotation)
            ) {
                val center = Offset(size.width / 2f, size.height / 2f)
                val radius = size.minDimension / 2f - 24.dp.toPx()

                // Dial ticks
                for (angle in 0 until 360 step 15) {
                    val isMajor = angle % 90 == 0
                    val isMedium = angle % 45 == 0
                    val tickLen = if (isMajor) 18.dp.toPx() else if (isMedium) 12.dp.toPx() else 7.dp.toPx()
                    val strokeW = if (isMajor) 3.dp.toPx() else if (isMedium) 2.dp.toPx() else 1.dp.toPx()
                    val color = if (isMajor) GoldPrimary else Color.White.copy(alpha = 0.5f)

                    val angleRad = Math.toRadians(angle.toDouble())
                    val start = Offset(
                        (center.x + (radius - tickLen) * sin(angleRad)).toFloat(),
                        (center.y - (radius - tickLen) * cos(angleRad)).toFloat()
                    )
                    val end = Offset(
                        (center.x + radius * sin(angleRad)).toFloat(),
                        (center.y - radius * cos(angleRad)).toFloat()
                    )
                    drawLine(color = color, start = start, end = end, strokeWidth = strokeW)
                }

                // Kaaba marker at target Qibla angle on the dial
                val qiblaRad = Math.toRadians(qiblaAngle.toDouble())
                val kaabaDist = radius - 38.dp.toPx()
                val kaabaCenter = Offset(
                    (center.x + kaabaDist * sin(qiblaRad)).toFloat(),
                    (center.y - kaabaDist * cos(qiblaRad)).toFloat()
                )
                drawCircle(
                    color = GoldGlow,
                    radius = 16.dp.toPx(),
                    center = kaabaCenter
                )
                drawCircle(
                    color = Color.Black,
                    radius = 12.dp.toPx(),
                    center = kaabaCenter
                )
                // Kaaba golden rim
                drawCircle(
                    color = GoldPrimary,
                    radius = 12.dp.toPx(),
                    center = kaabaCenter,
                    style = Stroke(width = 2.dp.toPx())
                )
            }

            // Fixed needle pointing UP (towards device's heading / Kaaba when aligned)
            Canvas(modifier = Modifier.fillMaxSize()) {
                val center = Offset(size.width / 2f, size.height / 2f)
                val needleLength = size.minDimension / 2f - 40.dp.toPx()
                val needleWidth = 14.dp.toPx()

                // North arrow (upwards)
                val northPath = Path().apply {
                    moveTo(center.x, center.y - needleLength)
                    lineTo(center.x + needleWidth / 2, center.y)
                    lineTo(center.x - needleWidth / 2, center.y)
                    close()
                }
                drawPath(
                    path = northPath,
                    brush = Brush.verticalGradient(
                        colors = if (isAligned) listOf(GoldGlow, GoldPrimary) else listOf(KarbalaRedLight, KarbalaRed)
                    )
                )

                // South arrow (downwards)
                val southPath = Path().apply {
                    moveTo(center.x, center.y + needleLength * 0.75f)
                    lineTo(center.x + needleWidth / 2, center.y)
                    lineTo(center.x - needleWidth / 2, center.y)
                    close()
                }
                drawPath(
                    path = southPath,
                    brush = Brush.verticalGradient(
                        colors = listOf(Color.Gray, Color.DarkGray)
                    )
                )

                // Center hub
                drawCircle(color = GoldPrimary, radius = 10.dp.toPx(), center = center)
                drawCircle(color = Color.Black, radius = 5.dp.toPx(), center = center)
            }

            // Direction text badge at bottom of dial
            Column(
                modifier = Modifier
                    .align(Alignment.BottomCenter)
                    .padding(bottom = 20.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text(
                    text = if (isAligned) "مكة المكرمة" else "${currentAzimuth.roundToInt()}°",
                    color = if (isAligned) GoldLight else Color.White,
                    fontWeight = FontWeight.Bold,
                    fontSize = 13.sp
                )
            }
        }

        Spacer(modifier = Modifier.height(10.dp))

        // Status Banner & Calibration Tip
        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(
                containerColor = if (isAligned) EmeraldPrimary.copy(alpha = 0.2f)
                else MaterialTheme.colorScheme.surfaceVariant
            ),
            border = if (isAligned) ButtonDefaults.outlinedButtonBorder.copy(
                brush = Brush.linearGradient(listOf(GoldPrimary, GoldLight))
            ) else null
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(14.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text(
                    text = if (isAligned)
                        (if (isArabic) "✓ أنت الآن باتجاه الكعبة المشرفة والقبلة تماماً" else "Aligned with Kaaba")
                    else
                        (if (isArabic) "قم بتدوير الهاتف حتى يتطابق المؤشر الذهبي مع السهم" else "Rotate phone to align needle with Kaaba"),
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Bold,
                    color = if (isAligned) GoldSecondary else MaterialTheme.colorScheme.onSurface,
                    textAlign = TextAlign.Center
                )

                Spacer(modifier = Modifier.height(6.dp))

                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.CompassCalibration,
                        contentDescription = "Calibration",
                        tint = MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = if (isArabic) "لدقة أعلى: حرك الهاتف على شكل رقم (8) لمعايرة البوصلة" else "Move phone in figure-8 motion for calibration",
                        fontSize = 11.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(60.dp))
    }
}
