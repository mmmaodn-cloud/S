package com.example.ui.screens

import android.content.Context
import android.net.Uri
import android.provider.OpenableColumns
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.audio.AdhanManager
import com.example.data.AppPreferences
import com.example.data.City
import com.example.data.CityRepository
import com.example.ui.theme.*

@Composable
fun SettingsScreen(
    appPrefs: AppPreferences,
    currentCity: City,
    onCityChanged: (City) -> Unit,
    isDarkMode: Boolean,
    onDarkModeChanged: (Boolean) -> Unit,
    currentLanguage: String,
    onLanguageChanged: (String) -> Unit
) {
    val context = LocalContext.current
    val coroutineScope = rememberCoroutineScope()
    var showCityDialog by remember { mutableStateOf(false) }
    var showMuadhinDialog by remember { mutableStateOf(false) }

    val currentMuadhinId by AdhanManager.currentMuadhinId.collectAsState()
    val customToneName by AdhanManager.customToneName.collectAsState()
    val isPlayingAdhan by AdhanManager.isPlaying.collectAsState()

    var notifyFajr by remember { mutableStateOf(appPrefs.notifyFajr) }
    var notifyDhuhr by remember { mutableStateOf(appPrefs.notifyDhuhr) }
    var notifyMaghrib by remember { mutableStateOf(appPrefs.notifyMaghrib) }

    // Audio file picker from device storage / studio (SAF)
    val audioPickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.GetContent()
    ) { uri: Uri? ->
        if (uri != null) {
            val fileName = queryFileName(context, uri) ?: "نغمة أذان مخصصة"
            appPrefs.customToneUri = uri.toString()
            appPrefs.customToneName = fileName
            appPrefs.muadhinId = "custom"
            AdhanManager.setCustomUri(uri, fileName)
        }
    }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp),
        contentPadding = PaddingValues(top = 16.dp, bottom = 100.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        // App Title Banner
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(18.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(
                        modifier = Modifier
                            .size(50.dp)
                            .clip(CircleShape)
                            .background(EmeraldPrimary)
                            .border(1.5.dp, GoldPrimary, CircleShape),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.Mosque,
                            contentDescription = "Ahl Al Bayt",
                            tint = GoldLight,
                            modifier = Modifier.size(28.dp)
                        )
                    }
                    Spacer(modifier = Modifier.width(14.dp))
                    Column {
                        Text(
                            text = "تطبيق آل البيت (عليهم السلام)",
                            fontWeight = FontWeight.ExtraBold,
                            fontSize = 17.sp,
                            color = GoldSecondary
                        )
                        Text(
                            text = "المواقيت • الأذان الشيعي • القبلة • المسبحة • القرآن",
                            fontSize = 11.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }
        }

        // Section 1: Display & Theme (وضع ليلي ونهاري)
        item {
            SettingsCategoryHeader("المظهر والعرض")
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = if (isDarkMode) Icons.Default.DarkMode else Icons.Default.LightMode,
                                contentDescription = "Night Mode",
                                tint = GoldPrimary
                            )
                            Spacer(modifier = Modifier.width(12.dp))
                            Column {
                                Text(
                                    text = if (isDarkMode) "الوضع الليلي (مفعل)" else "الوضع النهاري (مفعل)",
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 15.sp,
                                    color = MaterialTheme.colorScheme.onSurface
                                )
                                Text(
                                    text = if (isDarkMode) "ألوان إسلامية داكنة مريحة للعين" else "ألوان فاتحة ناصعة",
                                    fontSize = 12.sp,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }
                        Switch(
                            checked = isDarkMode,
                            onCheckedChange = { checked ->
                                onDarkModeChanged(checked)
                                appPrefs.isDarkMode = checked
                            },
                            colors = SwitchDefaults.colors(
                                checkedThumbColor = GoldPrimary,
                                checkedTrackColor = EmeraldPrimary
                            )
                        )
                    }
                }
            }
        }

        // Section 2: Language Selector (تغيير اللغة)
        item {
            SettingsCategoryHeader("اللغة (Language)")
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    val languages = listOf(
                        Pair("ar", "العربية (Arabic)"),
                        Pair("en", "English"),
                        Pair("fa", "فارسی (Persian)"),
                        Pair("ur", "اردو (Urdu)")
                    )
                    languages.forEach { (code, label) ->
                        val isSelected = currentLanguage == code
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(10.dp))
                                .clickable {
                                    onLanguageChanged(code)
                                    appPrefs.language = code
                                }
                                .padding(vertical = 10.dp, horizontal = 8.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = label,
                                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                                color = if (isSelected) GoldSecondary else MaterialTheme.colorScheme.onSurface,
                                fontSize = 14.sp
                            )
                            if (isSelected) {
                                Icon(
                                    imageVector = Icons.Default.Check,
                                    contentDescription = "Selected",
                                    tint = GoldPrimary
                                )
                            }
                        }
                    }
                }
            }
        }

        // Section 3: Adhan Ringtone & Studio Picker (نغمة الأذان واختيار من الاستوديو)
        item {
            SettingsCategoryHeader("نغمة الأذان والمؤذن الشيعي")
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
            ) {
                Column(
                    modifier = Modifier.padding(14.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    // Selected Muadhin row
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(10.dp))
                            .clickable { showMuadhinDialog = true }
                            .padding(vertical = 4.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.Campaign, contentDescription = null, tint = GoldPrimary)
                            Spacer(modifier = Modifier.width(12.dp))
                            Column {
                                Text(
                                    text = "صوت المؤذن المختار",
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 14.sp,
                                    color = MaterialTheme.colorScheme.onSurface
                                )
                                val currentM = AdhanManager.muadhins.firstOrNull { it.id == currentMuadhinId }
                                Text(
                                    text = currentM?.nameAr ?: "أذان العتبة العلوية المقدسة",
                                    fontSize = 12.sp,
                                    color = GoldDark
                                )
                            }
                        }
                        Icon(Icons.Default.ArrowDropDown, contentDescription = "Choose", tint = GoldPrimary)
                    }

                    HorizontalDivider(color = MaterialTheme.colorScheme.outline.copy(alpha = 0.2f))

                    // Choose Custom Audio from Studio / Storage
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = "اختيار نغمة من الاستوديو / الهاتف",
                                fontWeight = FontWeight.Bold,
                                fontSize = 14.sp,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                            Text(
                                text = customToneName ?: "اختر ملفك الصوتي المفضل",
                                fontSize = 11.sp,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }

                        Button(
                            onClick = {
                                audioPickerLauncher.launch("audio/*")
                            },
                            shape = RoundedCornerShape(10.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = EmeraldPrimary)
                        ) {
                            Icon(Icons.Default.LibraryMusic, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("الاستوديو", fontSize = 12.sp)
                        }
                    }
                }
            }
        }

        // Section 4: Governorate & Country Selection (المحافظات والدول)
        item {
            SettingsCategoryHeader("الموقع والمحافظة")
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(16.dp))
                        .clickable { showCityDialog = true }
                        .padding(14.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.LocationCity, contentDescription = null, tint = GoldPrimary)
                        Spacer(modifier = Modifier.width(12.dp))
                        Column {
                            Text(
                                text = currentCity.nameAr,
                                fontWeight = FontWeight.Bold,
                                fontSize = 15.sp,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                            Text(
                                text = "${currentCity.countryAr} • خط ${currentCity.latitude}، ${currentCity.longitude}",
                                fontSize = 11.sp,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                    OutlinedButton(
                        onClick = { showCityDialog = true },
                        shape = RoundedCornerShape(10.dp)
                    ) {
                        Text("تغيير", fontSize = 12.sp, color = GoldSecondary)
                    }
                }
            }
        }

        // Section 5: Prayer Notifications
        item {
            SettingsCategoryHeader("تنبيهات الصلاة والأذان")
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    NotificationToggleRow("تنبيه صلاة الفجر", notifyFajr) {
                        notifyFajr = it
                        appPrefs.notifyFajr = it
                    }
                    HorizontalDivider(modifier = Modifier.padding(vertical = 4.dp), color = MaterialTheme.colorScheme.outline.copy(alpha = 0.2f))
                    NotificationToggleRow("تنبيه صلاة الظهر والعصر", notifyDhuhr) {
                        notifyDhuhr = it
                        appPrefs.notifyDhuhr = it
                    }
                    HorizontalDivider(modifier = Modifier.padding(vertical = 4.dp), color = MaterialTheme.colorScheme.outline.copy(alpha = 0.2f))
                    NotificationToggleRow("تنبيه صلاة المغرب والعشاء", notifyMaghrib) {
                        notifyMaghrib = it
                        appPrefs.notifyMaghrib = it
                    }
                }
            }
        }
    }

    // City Selection Dialog
    if (showCityDialog) {
        CitySelectionDialog(
            currentCity = currentCity,
            onDismiss = { showCityDialog = false },
            onSelect = { city ->
                onCityChanged(city)
                appPrefs.selectedCityId = city.id
                showCityDialog = false
            }
        )
    }

    // Shia Mu'adhins Selection Dialog
    if (showMuadhinDialog) {
        AlertDialog(
            onDismissRequest = { showMuadhinDialog = false },
            title = { Text("اختر صوت المؤذن الشيعي", fontWeight = FontWeight.Bold) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    AdhanManager.muadhins.forEach { m ->
                        val isSel = m.id == currentMuadhinId
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(8.dp))
                                .background(if (isSel) GoldPrimary.copy(alpha = 0.2f) else Color.Transparent)
                                .clickable {
                                    AdhanManager.setMuadhin(m.id)
                                    appPrefs.muadhinId = m.id
                                    showMuadhinDialog = false
                                }
                                .padding(10.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column {
                                Text(
                                    text = m.nameAr,
                                    fontWeight = if (isSel) FontWeight.Bold else FontWeight.Normal,
                                    color = if (isSel) GoldSecondary else MaterialTheme.colorScheme.onSurface
                                )
                                Text(
                                    text = m.shrine,
                                    fontSize = 11.sp,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                            if (isSel) {
                                Icon(Icons.Default.Check, contentDescription = "Selected", tint = GoldPrimary)
                            }
                        }
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = { showMuadhinDialog = false }) {
                    Text("إغلاق", color = GoldPrimary)
                }
            }
        )
    }
}

@Composable
fun SettingsCategoryHeader(title: String) {
    Text(
        text = title,
        fontWeight = FontWeight.Bold,
        fontSize = 14.sp,
        color = GoldSecondary,
        modifier = Modifier.padding(start = 4.dp, top = 6.dp)
    )
}

@Composable
fun NotificationToggleRow(
    label: String,
    checked: Boolean,
    onCheckedChange: (Boolean) -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 6.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(
            text = label,
            fontSize = 14.sp,
            fontWeight = FontWeight.Medium,
            color = MaterialTheme.colorScheme.onSurface
        )
        Switch(
            checked = checked,
            onCheckedChange = onCheckedChange,
            colors = SwitchDefaults.colors(
                checkedThumbColor = GoldPrimary,
                checkedTrackColor = EmeraldPrimary
            )
        )
    }
}

// Helper to query file display name from SAF Content Uri
fun queryFileName(context: Context, uri: Uri): String? {
    var result: String? = null
    if (uri.scheme == "content") {
        val cursor = context.contentResolver.query(uri, null, null, null, null)
        cursor?.use {
            if (it.moveToFirst()) {
                val idx = it.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                if (idx != -1) {
                    result = it.getString(idx)
                }
            }
        }
    }
    if (result == null) {
        result = uri.path
        val cut = result?.lastIndexOf('/')
        if (cut != null && cut != -1) {
            result = result?.substring(cut + 1)
        }
    }
    return result
}
