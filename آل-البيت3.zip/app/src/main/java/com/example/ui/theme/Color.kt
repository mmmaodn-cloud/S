package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Sacred Islamic Emerald Palette
val EmeraldDark = Color(0xFF072317)
val EmeraldPrimary = Color(0xFF0E4D34)
val EmeraldMedium = Color(0xFF1B6B4B)
val EmeraldLight = Color(0xFF2E956C)
val EmeraldAccent = Color(0xFF4ADE80)

// Holy Golden Accents (Imam Hussain & Imam Ali Domes)
val GoldLight = Color(0xFFFDE68A)
val GoldPrimary = Color(0xFFD4AF37)
val GoldSecondary = Color(0xFFC59B27)
val GoldDark = Color(0xFF996515)
val GoldGlow = Color(0xFFFFE57F)

// Sacred Crimson (Karbala Flag of Ya Hussain)
val KarbalaRed = Color(0xFF8B0000)
val KarbalaRedLight = Color(0xFFB91C1C)

// Surfaces & Backgrounds
val DarkCanvas = Color(0xFF09140E)
val DarkSurface = Color(0xFF102119)
val DarkSurfaceElevated = Color(0xFF182E23)
val DarkBorder = Color(0xFF244434)

val LightCanvas = Color(0xFFF8F6F0)
val LightSurface = Color(0xFFFFFFFF)
val LightSurfaceElevated = Color(0xFFEFECE4)
val LightBorder = Color(0xFFDDD7C8)

// Texts
val TextGold = Color(0xFFFFDF7D)
val TextPrimaryLight = Color(0xFF1A1A1A)
val TextSecondaryLight = Color(0xFF555555)
val TextPrimaryDark = Color(0xFFF3F4F6)
val TextSecondaryDark = Color(0xFF9CA3AF)
