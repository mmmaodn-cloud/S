package com.example.ui.screens

import android.text.format.DateFormat
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.*
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.audio.AdhanManager
import com.example.data.City
import com.example.data.CityRepository
import com.example.data.PrayerTimeCalculator
import com.example.ui.theme.*
import kotlinx.coroutines.delay
import java.util.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PrayersScreen(
    currentCity: City,
    onCitySelected: (City) -> Unit,
    isArabic: Boolean = true
) {
    val context = LocalContext.current
    val coroutineScope = rememberCoroutineScope()
    var showCityDialog by remember { mutableStateOf(false) }

    // Live clock update every 10 seconds
    var currentTime by remember { mutableStateOf(Date()) }
    LaunchedEffect(Unit) {
        while (true) {
            delay(10000)
            currentTime = Date()
        }
    }

    val prayerTimes = remember(currentCity, currentTime) {
        PrayerTimeCalculator.calculateTimes(currentCity, currentTime)
    }

    val isPlaying by AdhanManager.isPlaying.collectAsState()
    val currentPhraseIdx by AdhanManager.currentPhraseIndex.collectAsState()
    val currentMuadhinId by AdhanManager.currentMuadhinId.collectAsState()
    val muadhin = remember(currentMuadhinId) {
        AdhanManager.muadhins.firstOrNull { it.id == currentMuadhinId } ?: AdhanManager.muadhins[0]
    }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp),
        contentPadding = PaddingValues(top = 16.dp, bottom = 100.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        // City and Date Header Card
        item {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(20.dp)),
                colors = CardDefaults.cardColors(
                    containerColor = MaterialTheme.colorScheme.surfaceVariant
                ),
                elevation = CardDefaults.cardElevation(defaultElevation = 3.dp)
            ) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(
                            Brush.verticalGradient(
                                colors = listOf(
                                    EmeraldPrimary.copy(alpha = 0.85f),
                                    EmeraldDark
                                )
                            )
                        )
                        .padding(18.dp)
                ) {
                    Column {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column {
                                Text(
                                    text = if (isArabic) "مواقيت الصلاة • وفق المذهب الشيعي" else "Shia Prayer Times",
                                    color = GoldLight,
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Medium
                                )
                                Spacer(modifier = Modifier.height(4.dp))
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    modifier = Modifier
                                        .clip(RoundedCornerShape(8.dp))
                                        .clickable { showCityDialog = true }
                                        .background(Color.White.copy(alpha = 0.12f))
                                        .padding(horizontal = 10.dp, vertical = 6.dp)
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.LocationOn,
                                        contentDescription = "Location",
                                        tint = GoldPrimary,
                                        modifier = Modifier.size(18.dp)
                                    )
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text(
                                        text = if (isArabic) currentCity.nameAr else currentCity.nameEn,
                                        color = Color.White,
                                        fontSize = 15.sp,
                                        fontWeight = FontWeight.Bold
                                    )
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Icon(
                                        imageVector = Icons.Default.ArrowDropDown,
                                        contentDescription = "Change city",
                                        tint = GoldLight,
                                        modifier = Modifier.size(20.dp)
                                    )
                                }
                            }

                            // Next Prayer Badge
                            Surface(
                                shape = RoundedCornerShape(14.dp),
                                color = GoldPrimary.copy(alpha = 0.2f),
                                border = ButtonDefaults.outlinedButtonBorder.copy(
                                    brush = Brush.linearGradient(listOf(GoldPrimary, GoldLight))
                                )
                            ) {
                                Column(
                                    modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp),
                                    horizontalAlignment = Alignment.CenterHorizontally
                                ) {
                                    Text(
                                        text = if (isArabic) "الصلاة القادمة" else "Next",
                                        color = GoldLight,
                                        fontSize = 10.sp
                                    )
                                    Text(
                                        text = if (isArabic) prayerTimes.nextPrayerNameAr else prayerTimes.nextPrayerNameEn,
                                        color = Color.White,
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 14.sp
                                    )
                                    Text(
                                        text = prayerTimes.nextPrayerRemainingFormatted,
                                        color = GoldLight,
                                        fontWeight = FontWeight.SemiBold,
                                        fontSize = 12.sp
                                    )
                                }
                            }
                        }

                        Spacer(modifier = Modifier.height(14.dp))

                        // Next prayer progress bar
                        LinearProgressIndicator(
                            progress = { prayerTimes.nextPrayerProgress },
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(6.dp)
                                .clip(CircleShape),
                            color = GoldPrimary,
                            trackColor = Color.White.copy(alpha = 0.2f),
                        )
                    }
                }
            }
        }

        // Shia Adhan Audio Player Card
        item {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .border(
                        1.dp,
                        if (isPlaying) GoldPrimary else Color.Transparent,
                        RoundedCornerShape(18.dp)
                    ),
                shape = RoundedCornerShape(18.dp),
                colors = CardDefaults.cardColors(
                    containerColor = MaterialTheme.colorScheme.surface
                ),
                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Box(
                                modifier = Modifier
                                    .size(42.dp)
                                    .clip(CircleShape)
                                    .background(if (isPlaying) KarbalaRed else EmeraldPrimary),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    imageVector = if (isPlaying) Icons.Default.VolumeUp else Icons.Default.Campaign,
                                    contentDescription = "Adhan",
                                    tint = GoldLight,
                                    modifier = Modifier.size(22.dp)
                                )
                            }
                            Spacer(modifier = Modifier.width(12.dp))
                            Column {
                                Text(
                                    text = if (isArabic) "الأذان الشيعي المبارك" else "Shia Adhan",
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 15.sp,
                                    color = MaterialTheme.colorScheme.onSurface
                                )
                                Text(
                                    text = if (isArabic) muadhin.nameAr else muadhin.nameEn,
                                    fontSize = 12.sp,
                                    color = GoldDark
                                )
                            }
                        }

                        // Play/Stop button
                        FilledTonalButton(
                            onClick = {
                                if (isPlaying) {
                                    AdhanManager.stopAdhan()
                                } else {
                                    AdhanManager.playAdhan(context, coroutineScope)
                                }
                            },
                            colors = ButtonDefaults.filledTonalButtonColors(
                                containerColor = if (isPlaying) KarbalaRed else EmeraldPrimary,
                                contentColor = Color.White
                            ),
                            shape = RoundedCornerShape(12.dp)
                        ) {
                            Icon(
                                imageVector = if (isPlaying) Icons.Default.Stop else Icons.Default.PlayArrow,
                                contentDescription = if (isPlaying) "Stop" else "Play",
                                modifier = Modifier.size(18.dp)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = if (isPlaying) (if (isArabic) "إيقاف" else "Stop") else (if (isArabic) "استماع للأذان" else "Play Adhan"),
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }

                    // Live Adhan phrase banner when playing
                    AnimatedVisibility(visible = isPlaying) {
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(top = 12.dp)
                                .clip(RoundedCornerShape(12.dp))
                                .background(GoldPrimary.copy(alpha = 0.12f))
                                .border(1.dp, GoldPrimary.copy(alpha = 0.4f), RoundedCornerShape(12.dp))
                                .padding(12.dp),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            Text(
                                text = AdhanManager.shiaAdhanPhrases.getOrElse(currentPhraseIdx) {
                                    "أَشْهَدُ أَنَّ عَلِيّاً وَلِيُّ اللهِ"
                                },
                                color = GoldSecondary,
                                fontSize = 16.sp,
                                fontWeight = FontWeight.ExtraBold,
                                textAlign = TextAlign.Center
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = if (isArabic) "يرتفع الآن الأذان مع الشهادة الثالثة وحي على خير العمل" else "Playing Shia Adhan with 3rd Shahada",
                                fontSize = 11.sp,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                }
            }
        }

        // Section Title
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = if (isArabic) "جدول الأوقات الشرعية اليوم" else "Today's Prayer Schedule",
                    fontSize = 16.sp,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onBackground
                )
                Text(
                    text = if (isArabic) "بتوقيت " + currentCity.nameAr else currentCity.nameEn,
                    fontSize = 12.sp,
                    color = GoldDark
                )
            }
        }

        // Prayer Items List
        item {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                PrayerItemRow("الإمساك", "Imsak", prayerTimes.imsak, Icons.Default.NightsStay, prayerTimes.nextPrayerNameAr == "الإمساك")
                PrayerItemRow("صلاة الفجر", "Fajr", prayerTimes.fajr, Icons.Default.WbTwilight, prayerTimes.nextPrayerNameAr == "الفجر")
                PrayerItemRow("الشروق", "Sunrise", prayerTimes.sunrise, Icons.Default.WbSunny, prayerTimes.nextPrayerNameAr == "الشروق", isDim = true)
                PrayerItemRow("صلاة الظهر", "Dhuhr", prayerTimes.dhuhr, Icons.Default.LightMode, prayerTimes.nextPrayerNameAr == "الظهر")
                PrayerItemRow("صلاة العصر", "Asr", prayerTimes.asr, Icons.Default.WbSunny, prayerTimes.nextPrayerNameAr == "العصر")
                PrayerItemRow("الغروب", "Sunset", prayerTimes.sunset, Icons.Default.WbTwilight, prayerTimes.nextPrayerNameAr == "الغروب", isDim = true)
                PrayerItemRow("صلاة المغرب", "Maghrib", prayerTimes.maghrib, Icons.Default.DarkMode, prayerTimes.nextPrayerNameAr == "المغرب")
                PrayerItemRow("صلاة العشاء", "Isha", prayerTimes.isha, Icons.Default.Bedtime, prayerTimes.nextPrayerNameAr == "العشاء")
                PrayerItemRow("منتصف الليل الشرعي", "Midnight", prayerTimes.midnight, Icons.Default.NightsStay, prayerTimes.nextPrayerNameAr == "منتصف الليل")
            }
        }
    }

    // City Selection Dialog (All 18 Iraqi governorates + World)
    if (showCityDialog) {
        CitySelectionDialog(
            currentCity = currentCity,
            onDismiss = { showCityDialog = false },
            onSelect = { city ->
                onCitySelected(city)
                showCityDialog = false
            },
            isArabic = isArabic
        )
    }
}

@Composable
fun PrayerItemRow(
    nameAr: String,
    nameEn: String,
    time: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    isNext: Boolean = false,
    isDim: Boolean = false
) {
    val bg = if (isNext) {
        Brush.horizontalGradient(listOf(EmeraldPrimary.copy(alpha = 0.2f), GoldPrimary.copy(alpha = 0.15f)))
    } else {
        Brush.horizontalGradient(listOf(MaterialTheme.colorScheme.surface, MaterialTheme.colorScheme.surface))
    }

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .border(
                width = if (isNext) 1.5.dp else 0.5.dp,
                color = if (isNext) GoldPrimary else MaterialTheme.colorScheme.outline.copy(alpha = 0.3f),
                shape = RoundedCornerShape(14.dp)
            ),
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .background(bg)
                .padding(horizontal = 16.dp, vertical = 12.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    modifier = Modifier
                        .size(36.dp)
                        .clip(CircleShape)
                        .background(
                            if (isNext) GoldPrimary.copy(alpha = 0.2f)
                            else MaterialTheme.colorScheme.surfaceVariant
                        ),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = icon,
                        contentDescription = nameAr,
                        tint = if (isNext) GoldPrimary else MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.size(20.dp)
                    )
                }
                Spacer(modifier = Modifier.width(12.dp))
                Column {
                    Text(
                        text = nameAr,
                        fontWeight = if (isNext) FontWeight.Bold else FontWeight.Medium,
                        fontSize = 15.sp,
                        color = if (isDim) MaterialTheme.colorScheme.onSurfaceVariant else MaterialTheme.colorScheme.onSurface
                    )
                    Text(
                        text = nameEn,
                        fontSize = 11.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }

            Row(verticalAlignment = Alignment.CenterVertically) {
                if (isNext) {
                    Surface(
                        shape = RoundedCornerShape(8.dp),
                        color = GoldPrimary,
                        modifier = Modifier.padding(end = 8.dp)
                    ) {
                        Text(
                            text = "التالي",
                            color = Color.Black,
                            fontWeight = FontWeight.Bold,
                            fontSize = 10.sp,
                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                        )
                    }
                }
                Text(
                    text = time,
                    fontSize = 18.sp,
                    fontWeight = FontWeight.ExtraBold,
                    color = if (isNext) GoldSecondary else MaterialTheme.colorScheme.onSurface
                )
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CitySelectionDialog(
    currentCity: City,
    onDismiss: () -> Unit,
    onSelect: (City) -> Unit,
    isArabic: Boolean = true
) {
    var selectedTab by remember { mutableStateOf(0) } // 0: العراق, 1: العالم
    var searchQuery by remember { mutableStateOf("") }

    val iraqCities = remember(searchQuery) {
        if (searchQuery.isBlank()) CityRepository.iraqGovernorates
        else CityRepository.iraqGovernorates.filter {
            it.nameAr.contains(searchQuery, true) || it.nameEn.contains(searchQuery, true)
        }
    }

    val worldCities = remember(searchQuery) {
        if (searchQuery.isBlank()) CityRepository.worldCities
        else CityRepository.worldCities.filter {
            it.nameAr.contains(searchQuery, true) || it.nameEn.contains(searchQuery, true) ||
            it.countryAr.contains(searchQuery, true)
        }
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        modifier = Modifier.fillMaxWidth(0.95f)
    ) {
        Surface(
            shape = RoundedCornerShape(24.dp),
            color = MaterialTheme.colorScheme.surface,
            tonalElevation = 6.dp
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text(
                    text = if (isArabic) "اختر المحافظة أو المدينة" else "Select Governorate / City",
                    fontSize = 18.sp,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onSurface,
                    modifier = Modifier.padding(bottom = 8.dp)
                )

                // Search Box
                OutlinedTextField(
                    value = searchQuery,
                    onValueChange = { searchQuery = it },
                    modifier = Modifier.fillMaxWidth(),
                    placeholder = { Text(if (isArabic) "ابحث عن محافظة (بغداد، النجف، كربلاء...)" else "Search city...") },
                    leadingIcon = { Icon(Icons.Default.Search, contentDescription = "Search") },
                    singleLine = true,
                    shape = RoundedCornerShape(12.dp)
                )

                Spacer(modifier = Modifier.height(10.dp))

                // Tabs
                TabRow(
                    selectedTabIndex = selectedTab,
                    containerColor = Color.Transparent,
                    contentColor = GoldPrimary
                ) {
                    Tab(
                        selected = selectedTab == 0,
                        onClick = { selectedTab = 0 },
                        text = {
                            Text(
                                text = if (isArabic) "محافظات العراق (18)" else "Iraq (18)",
                                fontWeight = FontWeight.Bold
                            )
                        }
                    )
                    Tab(
                        selected = selectedTab == 1,
                        onClick = { selectedTab = 1 },
                        text = {
                            Text(
                                text = if (isArabic) "العتبات والعالم" else "World & Holy Shrines",
                                fontWeight = FontWeight.Bold
                            )
                        }
                    )
                }

                Spacer(modifier = Modifier.height(8.dp))

                // Cities List
                val displayList = if (selectedTab == 0) iraqCities else worldCities
                LazyColumn(
                    modifier = Modifier
                        .fillMaxWidth()
                        .heightIn(max = 350.dp),
                    verticalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    items(displayList) { city ->
                        val isSelected = city.id == currentCity.id
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(10.dp))
                                .background(
                                    if (isSelected) GoldPrimary.copy(alpha = 0.2f)
                                    else Color.Transparent
                                )
                                .clickable { onSelect(city) }
                                .padding(horizontal = 12.dp, vertical = 10.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column {
                                Text(
                                    text = if (isArabic) city.nameAr else city.nameEn,
                                    fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                                    color = if (isSelected) GoldSecondary else MaterialTheme.colorScheme.onSurface,
                                    fontSize = 14.sp
                                )
                                Text(
                                    text = if (isArabic) city.countryAr else city.countryEn,
                                    fontSize = 11.sp,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                            if (isSelected) {
                                Icon(
                                    imageVector = Icons.Default.CheckCircle,
                                    contentDescription = "Selected",
                                    tint = GoldPrimary,
                                    modifier = Modifier.size(20.dp)
                                )
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
                    TextButton(onClick = onDismiss) {
                        Text(if (isArabic) "إلغاء" else "Cancel", color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }
            }
        }
    }
}
