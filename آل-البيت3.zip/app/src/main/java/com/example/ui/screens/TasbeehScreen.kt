package com.example.ui.screens

import android.content.Context
import android.media.AudioManager
import android.media.ToneGenerator
import android.os.Build
import android.os.VibrationEffect
import android.os.Vibrator
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.VolumeOff
import androidx.compose.material.icons.filled.VolumeUp
import androidx.compose.material.icons.filled.Vibration
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.AppPreferences
import com.example.ui.theme.*

data class DhikrPreset(
    val id: String,
    val titleAr: String,
    val target: Int,
    val isZahra: Boolean = false
)

@Composable
fun TasbeehScreen(
    appPrefs: AppPreferences,
    isArabic: Boolean = true
) {
    val context = LocalContext.current
    val vibrator = remember {
        @Suppress("DEPRECATION")
        context.getSystemService(Context.VIBRATOR_SERVICE) as? Vibrator
    }
    val toneGen = remember {
        try {
            ToneGenerator(AudioManager.STREAM_MUSIC, 60)
        } catch (e: Exception) {
            null
        }
    }

    val presets = remember {
        listOf(
            DhikrPreset("zahra", "تسبيحة الزهراء (ع)", 100, isZahra = true),
            DhikrPreset("salawat", "اللهم صلِّ على محمد وآل محمد", 100),
            DhikrPreset("istighfar", "أستغفر الله ربي وأتوب إليه", 70),
            DhikrPreset("tahlil", "لا إله إلا الله", 100),
            DhikrPreset("subhan", "سبحان الله والحمد لله", 33),
            DhikrPreset("ya_ali", "يا علي مدد", 110),
            DhikrPreset("ya_hussain", "يا حسين يا مظلوم", 128)
        )
    }

    var selectedPresetIndex by remember { mutableStateOf(0) }
    val currentPreset = presets[selectedPresetIndex]

    var count by remember { mutableStateOf(appPrefs.tasbeehCurrentCount) }
    var lifetimeCount by remember { mutableStateOf(appPrefs.tasbeehTotalCount) }
    var soundEnabled by remember { mutableStateOf(true) }
    var vibrationEnabled by remember { mutableStateOf(true) }

    // Zahra sub-phase calculation
    // 0..33: 34 Allahu Akbar
    // 34..66: 33 Alhamdulillah
    // 67..99: 33 SubhanAllah
    val zahraPhase = remember(count, currentPreset) {
        if (!currentPreset.isZahra) ""
        else when {
            count < 34 -> "اللهُ أَكْبَرُ (34)"
            count < 67 -> "الْحَمْدُ لِلَّهِ (33)"
            count < 100 -> "سُبْحَانَ اللهِ (33)"
            else -> "اكتملت تسبيحة الزهراء عليها السلام"
        }
    }

    val target = currentPreset.target
    val progress = (count.toFloat() / target.coerceAtLeast(1)).coerceIn(0f, 1f)

    var isPressed by remember { mutableStateOf(false) }
    val scaleAnim by animateFloatAsState(
        targetValue = if (isPressed) 0.94f else 1.0f,
        animationSpec = spring(dampingRatio = 0.6f, stiffness = 600f),
        label = "btn_scale"
    )

    fun onIncrement() {
        isPressed = true
        val nextCount = if (count + 1 > target) 1 else count + 1
        count = nextCount
        lifetimeCount += 1

        appPrefs.tasbeehCurrentCount = count
        appPrefs.tasbeehTotalCount = lifetimeCount

        if (vibrationEnabled) {
            try {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                    val amp = if (nextCount == target) VibrationEffect.DEFAULT_AMPLITUDE else 60
                    val dur = if (nextCount == target) 120L else 25L
                    vibrator?.vibrate(VibrationEffect.createOneShot(dur, amp))
                } else {
                    @Suppress("DEPRECATION")
                    vibrator?.vibrate(30)
                }
            } catch (e: Exception) {}
        }

        if (soundEnabled) {
            try {
                if (nextCount == target) {
                    toneGen?.startTone(ToneGenerator.TONE_PROP_BEEP2, 150)
                } else {
                    toneGen?.startTone(ToneGenerator.TONE_PROP_BEEP, 30)
                }
            } catch (e: Exception) {}
        }
    }

    LaunchedEffect(isPressed) {
        if (isPressed) {
            kotlinx.coroutines.delay(80)
            isPressed = false
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.SpaceBetween
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Spacer(modifier = Modifier.height(10.dp))

            // Presets Horizontal Scroller
            LazyRow(
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                contentPadding = PaddingValues(horizontal = 4.dp)
            ) {
                itemsIndexed(presets) { idx, preset ->
                    val isSel = idx == selectedPresetIndex
                    FilterChip(
                        selected = isSel,
                        onClick = {
                            selectedPresetIndex = idx
                            count = 0
                            appPrefs.tasbeehCurrentCount = 0
                        },
                        label = {
                            Text(
                                text = preset.titleAr,
                                fontWeight = if (isSel) FontWeight.Bold else FontWeight.Normal,
                                fontSize = 12.sp
                            )
                        },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = GoldPrimary,
                            selectedLabelColor = Color.Black
                        )
                    )
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            // Current Dhikr Display Card
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(18.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text(
                        text = if (currentPreset.isZahra) zahraPhase else currentPreset.titleAr,
                        fontSize = 18.sp,
                        fontWeight = FontWeight.ExtraBold,
                        color = GoldSecondary,
                        textAlign = TextAlign.Center
                    )

                    Spacer(modifier = Modifier.height(6.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = if (isArabic) "المجموع الكلي: $lifetimeCount" else "Total: $lifetimeCount",
                            fontSize = 12.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        Text(
                            text = if (isArabic) "الهدف: $target" else "Target: $target",
                            fontSize = 12.sp,
                            fontWeight = FontWeight.SemiBold,
                            color = GoldDark
                        )
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    LinearProgressIndicator(
                        progress = { progress },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(6.dp)
                            .clip(CircleShape),
                        color = GoldPrimary,
                        trackColor = MaterialTheme.colorScheme.surfaceVariant
                    )
                }
            }
        }

        // Giant Circular Rosary Bead Button
        Box(
            modifier = Modifier
                .size(240.dp)
                .scale(scaleAnim)
                .clip(CircleShape)
                .background(
                    Brush.radialGradient(
                        colors = listOf(
                            EmeraldMedium,
                            EmeraldPrimary,
                            DarkCanvas
                        )
                    )
                )
                .border(
                    width = 4.dp,
                    brush = Brush.sweepGradient(
                        listOf(GoldLight, GoldPrimary, GoldSecondary, GoldLight)
                    ),
                    shape = CircleShape
                )
                .clickable(
                    interactionSource = remember { MutableInteractionSource() },
                    indication = null
                ) {
                    onIncrement()
                },
            contentAlignment = Alignment.Center
        ) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Text(
                    text = "$count",
                    fontSize = 54.sp,
                    fontWeight = FontWeight.Black,
                    color = GoldGlow
                )
                Text(
                    text = if (isArabic) "المس للتسبيح" else "Tap to count",
                    fontSize = 12.sp,
                    color = Color.White.copy(alpha = 0.8f),
                    fontWeight = FontWeight.Medium
                )
            }
        }

        // Action Controls Row (Reset, Sound, Vibration)
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .padding(bottom = 90.dp),
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 20.dp, vertical = 10.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Reset Button
                IconButton(
                    onClick = {
                        count = 0
                        appPrefs.tasbeehCurrentCount = 0
                    }
                ) {
                    Icon(
                        imageVector = Icons.Default.Refresh,
                        contentDescription = "Reset",
                        tint = KarbalaRedLight
                    )
                }

                // Vibration Toggle
                IconButton(
                    onClick = { vibrationEnabled = !vibrationEnabled }
                ) {
                    Icon(
                        imageVector = Icons.Default.Vibration,
                        contentDescription = "Vibration",
                        tint = if (vibrationEnabled) GoldPrimary else MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }

                // Sound Toggle
                IconButton(
                    onClick = { soundEnabled = !soundEnabled }
                ) {
                    Icon(
                        imageVector = if (soundEnabled) Icons.Default.VolumeUp else Icons.Default.VolumeOff,
                        contentDescription = "Sound",
                        tint = if (soundEnabled) GoldPrimary else MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        }
    }
}
