package com.example.ui.navigation

import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AccessTime
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Explore
import androidx.compose.material.icons.filled.Image
import androidx.compose.material.icons.filled.MenuBook
import androidx.compose.material.icons.filled.Settings
import androidx.compose.ui.graphics.vector.ImageVector

enum class AppScreen(
    val titleAr: String,
    val titleEn: String,
    val icon: ImageVector
) {
    PRAYERS("المواقيت", "Prayers", Icons.Default.AccessTime),
    QIBLA("القبلة", "Qibla", Icons.Default.Explore),
    TASBEEH("المسبحة", "Tasbeeh", Icons.Default.AutoAwesome),
    QURAN("القرآن", "Quran", Icons.Default.MenuBook),
    GALLERY("صور حسينية", "Husseini Art", Icons.Default.Image),
    SETTINGS("الإعدادات", "Settings", Icons.Default.Settings)
}
